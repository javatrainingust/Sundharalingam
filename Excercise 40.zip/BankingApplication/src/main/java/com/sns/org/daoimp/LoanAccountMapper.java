/***
 * Class name: LoanAccountMapper
 * Discription: This class used to implement rowmapper class and used for set to resultset
 * date:23.10.2020
 * */
package com.sns.org.daoimp;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sns.org.model.LoanAccount;

/***
 * LoanAccountMapper class used to implement rowmapper class and used for set to resultset
 * */
public class LoanAccountMapper implements RowMapper<LoanAccount> {
/***
 * used for set to resultset
 * */
	public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		LoanAccount la=new LoanAccount();
		la.setAccountHoderName(rs.getString("accountHoderName"));
		la.setAccountNumber(rs.getInt("accountNumber"));
		la.setEmi(rs.getInt("emi"));
		la.setLoanOutStanding(rs.getInt("loanOutStanding"));
		la.setTenture(rs.getInt("tenture"));
		return la;
	}

}
