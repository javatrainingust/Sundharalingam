/***
 * Classname: SBAccountDAOSQLImpl
 * 
 * Description:this class used to achive SQL dao for SBAccount
 *
 * Date:23.10.2020
 * 
*/
package com.sns.org.daoimp;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sns.org.model.SBAccount;
/***
 *SBAccountDAOSQLImpl class used to achive SQL dao for SBAccount
*/
@Repository
public class SBAccountDAOSQLImpl implements SBAccountDAO{
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;
		/**
		 * Set Data source
		 * */
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
		/**
		 * Get all accounts
		 * */
	public List<SBAccount> getAllAccounts() {
		String SQL = "select * from sbaccount";
	      List <SBAccount> accounts= jdbcTemplateObject.query(SQL, new SBAccountMapper());
		
		return accounts;
	}
/**
 * get account by specified account
 * */
	public SBAccount getAccountByAccountNumber(int accountNum) {
		String sql = "SELECT * FROM sbaccount WHERE accountNumber = ?";
		 
		SBAccount account = (SBAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNum }, new SBAccountMapper());
      
       return 	account;	
	}
/**
 * delete the account
 * */
	public void deleteAccount(int accountNum) {
		 String query="delete from sbaccount where accountNumber='"+accountNum+"' ";  
		 jdbcTemplateObject.update(query);  	
	}
/***
 * add account
 * */
	public boolean addAccount(SBAccount sba) {
		String sql = "INSERT INTO sbaccount " +
	            "(accountNumber, accountHoderName, balance,year,ratio) VALUES (?, ?, ?,?,?)";
	  
		jdbcTemplateObject.update(sql, new Object[] { sba.getAccountNumber(),
				sba.getAccountHoderName(), sba.getBalance(),sba.getYear(),sba.getRatio() 
	        });   
	  

		return true;
	}
/***
 * update account
 * **/
	public void updateAccount(SBAccount sba) {
		String query="update sbaccount set  accountHoderName='"+sba.getAccountHoderName()+"',balance='"+sba.getBalance()+"' where id='"+sba.getAccountNumber()+"' ";  
	    jdbcTemplateObject.update(query); 
	}

}
