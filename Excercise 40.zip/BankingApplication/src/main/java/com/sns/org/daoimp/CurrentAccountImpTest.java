/***
 * Classname:CurrentAccountImpTest
 * 
 * Description:this class used to achive dao for CurrentAccountImpTest
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;


import java.util.ArrayList;
import java.util.List;


import com.sns.org.model.CurrentAccount;
import com.sns.org.servics.CurrentAccountService;

/*** CurrentAccountImpTest class used to achive dao for CurrentAccountImpTest */
class CurrentAccountImpTest {
	/*
	 * List currentAccountImpTest; CurrentAccountService service=new
	 * CurrentAccountService();;
	 * 
	 *//***
		 * constructor for CurrentAccountImpTest
		 *
		 ***/
	/*
	 * public CurrentAccountImpTest() { currentAccountImpTest = new
	 * ArrayList<CurrentAccount>(); CurrentAccount account1 = new
	 * CurrentAccount(1510, "Sundhara", 200000, 786765); CurrentAccount account2 =
	 * new CurrentAccount(1511, "Viji", 80000, 87876); CurrentAccount account3 = new
	 * CurrentAccount(1512, "Aruthra", 980000, 186765); CurrentAccount account4 =
	 * new CurrentAccount(1513, "Athvi", 540000, 56765);
	 * currentAccountImpTest.add(account1); currentAccountImpTest.add(account2);
	 * currentAccountImpTest.add(account3); currentAccountImpTest.add(account4);
	 * 
	 * }
	 *//**
		 * Display all the accounts sorted by OverDraftLimit *
		 **/
	/*
	 * 
	 * @Test void testGetAllCurrentAccountSortedByOverDraftLimit() {
	 * 
	 * String expectedValue = "Sundhara";
	 * 
	 * List<CurrentAccount> currentAccount =
	 * service.getAllPermanentEmployeesSortedByBasicSalary();
	 * 
	 * String actualValue = currentAccount.get(0).getAccountHoderName();
	 * 
	 * assertEquals(expectedValue, actualValue);
	 * 
	 * }
	 *//**
		 * Display all the accounts sorted by names *
		 **/
	/*
	 * @Test void testGetAllCurrentAccountSortedByNames() {
	 * 
	 * String expectedValue = "Sundhara";
	 * 
	 * List<CurrentAccount> currentAccount = service.getAllAccountsSortedByNames();
	 * 
	 * String actualValue = currentAccount.get(0).getAccountHoderName();
	 * 
	 * assertEquals(expectedValue, actualValue); }
	 * 
	 *//**
		 * Display all the accounts*
		 **/
	/*
	*//**
		 * @Test void testGetAllAccounts() { List<CurrentAccount> expected = new
		 *       ArrayList<CurrentAccount>(); CurrentAccountImp daoImp = new
		 *       CurrentAccountImp(); expected = daoImp.getAllAccounts();
		 *       assertEquals(expected.size(), currentAccountImpTest.size());
		 * 
		 *       }
		 * 
		 *       /** Display accounts by accountNum*
		 **/
	/**
	 * @Test void testGetAccountByAccountNumber() { CurrentAccount expected =
	 *       (CurrentAccount) currentAccountImpTest.get(0); CurrentAccountImp daoImp
	 *       = new CurrentAccountImp(); CurrentAccount actual =
	 *       daoImp.getAccountByAccountNumber(1510);
	 *       assertEquals(expected.getAccountHoderName(),
	 *       actual.getAccountHoderName());
	 * 
	 *       }
	 **/
	/**
	 * 
	 * Delete the account *
	 * 
	 */
	/**
	 * @Test void testDeleteAccount() { List<CurrentAccount> expected = new
	 *       ArrayList<CurrentAccount>(); CurrentAccountImp daoImp = new
	 *       CurrentAccountImp(); daoImp.deleteAccount(1513); expected =
	 *       daoImp.getAllAccounts(); assertEquals(expected.size(),
	 *       currentAccountImpTest.size() - 1); }
	 **/
	/***
	 * add account
	 */
	/*
	 * @Test void testAddAccount() { CurrentAccountImp daoImp = new
	 * CurrentAccountImp();
	 * 
	 * int expected=4;
	 * 
	 * 
	 * service.addCurrentAccount(new CurrentAccount(1510, "Sundhara", 200000,
	 * 786765)); service.addCurrentAccount(new CurrentAccount(1511, "Viji", 80000,
	 * 87876)); service.addCurrentAccount(new CurrentAccount(1512, "Aruthra",
	 * 980000, 186765)); service.addCurrentAccount(new CurrentAccount(1513, "Athvi",
	 * 540000, 56765));
	 * 
	 * List<CurrentAccountDAO> actual=service.getAllAccounts();
	 * assertEquals(expected, actual.size()); }
	 * 
	 * update account*
	 * 
	 * @Test void testUpdateAccount() { float expected=800000; CurrentAccountImp
	 * daoImp = new CurrentAccountImp(); CurrentAccount actual =
	 * daoImp.getAccountByAccountNumber(1510); assertEquals(expected,
	 * actual.getBalance()); }
	 */}
