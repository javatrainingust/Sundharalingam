/***
 * Class name:SBAccountMapper
 * Discription: This class used to implement rowmapper class and used for set to resultset
 * date:23.10.2020
 * */
package com.sns.org.daoimp;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sns.org.model.SBAccount;
/***
 *SBAccountMapper class used to implement rowmapper class and used for set to resultset
 * */
public class SBAccountMapper implements RowMapper<SBAccount> {
/**
 * used for set to resultset
 * */
	public SBAccount mapRow(ResultSet rs, int rowNum) throws SQLException {

		SBAccount sb = new SBAccount();
		sb.setAccountHoderName(rs.getString("accountHoderName"));
		sb.setAccountNumber(rs.getInt("accountNumber"));
		sb.setBalance(rs.getInt("balance"));
		sb.setRatio(rs.getInt("ratio"));
		sb.setYear(rs.getInt("year"));
		return sb;
	}

}
