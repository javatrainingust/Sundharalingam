/***
 * Classname: SBAccountImpTest
 * 
 * Description:this class used to achive dao for SBAccountImpTest
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import java.util.ArrayList;
import java.util.List;


import com.sns.org.model.LoanAccount;
import com.sns.org.model.SBAccount;
import com.sns.org.servics.LoanAccountService;
import com.sns.org.servics.SBAccountService;

/***
 * SBAccountImpTest class used to achive dao for SBAccountImpTest
 * 
 */
class SBAccountImpTest {
	List sbAccountListTest;
	SBAccountService service = new SBAccountService();

	/* SBAccountImpTest constructor */
	public SBAccountImpTest() {

		sbAccountListTest = new ArrayList<SBAccount>();
		SBAccount account1 = new SBAccount(1510, "Sundhara", 50000);
		SBAccount account2 = new SBAccount(1511, "Aruthra", 90000);
		SBAccount account3 = new SBAccount(1512, "Viji", 99000);
		SBAccount account4 = new SBAccount(1513, "athvi", 66000);

		sbAccountListTest.add(account1);
		sbAccountListTest.add(account2);
		sbAccountListTest.add(account3);
		sbAccountListTest.add(account4);
	}
	/**
	 * Display all the accounts sorted by FDAmount *
	 **/
	/*
	 * @Test void testGetAllCurrentAccountSortedByFDAmount() {
	 * 
	 * String expectedValue = "Sundhara";
	 * 
	 * List<SBAccount> sbAccount = service.getAllFDAccountsSortedByFDAmount();
	 * 
	 * String actualValue = sbAccount.get(0).getAccountHoderName();
	 * 
	 * assertEquals(expectedValue, actualValue);
	 * 
	 * }
	 *//**
		 * Display all the accounts sorted by names *
		 **//*
			 * @Test void testGetAllCurrentAccountSortedByNames() {
			 * 
			 * String expectedValue = "Sundhara";
			 * 
			 * List<SBAccount> sbAccount = service.getAllAccountsSortedByNames();
			 * 
			 * String actualValue = sbAccount.get(0).getAccountHoderName();
			 * 
			 * assertEquals(expectedValue, actualValue); }
			 */
	/**
	 * Display all the accounts*
	 **/

	/*
	 * @Test void testGetAllAccounts() { List<SBAccount> expectedList = new
	 * ArrayList<SBAccount>(); SBAccountImp daoImp = new SBAccountImp();
	 * expectedList = daoImp.getAllAccounts(); assertEquals(
	 * expectedList.size(),sbAccountListTest.size()); } /** Display accounts by
	 * accountNum*
	 **/

	/*
	 * @Test void testGetAccountByAccountNumber() { SBAccount expected = (SBAccount)
	 * sbAccountListTest.get(0); SBAccountImp daoImp = new SBAccountImp(); SBAccount
	 * actual = daoImp.getAccountByAccountNumber(1510); assertEquals(
	 * expected.getAccountHoderName(),actual.getAccountHoderName()); } /** Delete
	 * the account
	 **/
	/*
	 * @Test void testDeleteAccount() { List<SBAccount> expected = new
	 * ArrayList<SBAccount>(); SBAccountImp daoImp = new SBAccountImp();
	 * daoImp.deleteAccount(1513); expected = daoImp.getAllAccounts();
	 * assertEquals(expected.size(),sbAccountListTest.size()-1); }
	 */
	/*
	 * @Test void testAddAccount() {
	 * 
	 * int expected=4;
	 * 
	 * service.addSBAccount(new SBAccount(1510, "Sundhara", 50000));
	 * service.addSBAccount(new SBAccount(1511, "Aruthra", 90000));
	 * service.addSBAccount(new SBAccount(1512, "Viji", 99000));
	 * service.addSBAccount(new SBAccount(1513, "athvi", 66000));
	 * 
	 * 
	 * List actual=service.getAllAccounts(); assertEquals(expected, actual.size());
	 * }
	 */
	/*
	 * update account
	 **/
	/*
	 * @Test void testUpdateAccount() { float expected=5000; SBAccountImp daoImp =
	 * new SBAccountImp(); SBAccount actual =
	 * daoImp.getAccountByAccountNumber(1510);
	 * 
	 * assertEquals(expected, actual.getBalance()); }
	 */
}
