/***
 * class: FDAccountSorting
 * 
 * Description:this class used to sort FDAccount class
 *
 * Date:07.10.2020
 * 
*/
package com.sns.org.servics;

public class FDAccountSorting {
	/**
	 * 
	 * Main method
	 */
	public static void main(String[] args) {
		FDAccountService service =  new FDAccountService();
		System.out.println("printing all accounts");
		
		service.getAllAccounts();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print Accounts after sorting by names");
		service.getAllAccountsSortedByNames();
		System.out.println("----------------------");
		System.out.println("Print accounts  after sorting based on balance");
		service.getAllFDAccountsSortedByBasicBalance();
	}

}
