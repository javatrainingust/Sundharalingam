/***
 * class: SBAccountComparator
 * 
 * Description:this class used to sort SBAccount by comparator 
 *
 * Date:07.10.2020
 * 
*/
package com.sns.org.servics;

import java.util.Comparator;

import com.sns.org.model.SBAccount;
/***
 *SBAccountComparator class used to sort SBAccount by comparator 
*/
public class SBAccountComparator implements Comparator<SBAccount> {
	
	public int compare(SBAccount one, SBAccount two) {
		// TODO Auto-generated method stub
		return (int)(one.getBalance()-two.getBalance());
		}}

