/***
 * class: CurrentAccountService
 * 
 * Description:this class used to implement CurrentAccountService
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.servics;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.sns.org.daoimp.CurrentAccountDAO;
import com.sns.org.daoimp.CurrentAccountImp;
import com.sns.org.daoimp.FDADAO;
import com.sns.org.daoimp.FDADAOImp;
import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;

/***
 * CurrentAccountService class used to implement CurrentAccountService
 * 
 */
public class CurrentAccountService {
	CurrentAccountDAO daoImpl;
	CurrentAccountImp currentAccountImpl = new CurrentAccountImp();

	/* CurrentAccountService constructor */
	public CurrentAccountService() {
		daoImpl = new CurrentAccountImp();
	}

	/**
	 * Display all the accounts*
	 **/

	public List<CurrentAccountDAO> getAllAccounts() {
		List l = null;
		List currentAccountList = daoImpl.getAllAccounts();

		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = iterator.next();
			System.out.println("Account Holder Name:" + ca.getAccountHoderName());
			System.out.println("Account Number:" + ca.getAccountNumber());
			System.out.println("OverDraft Limit:" + ca.getOverdraftLimit());
			System.out.println("Balance:" + ca.getBalance());
			System.out.println("************************************************");

		}

		return currentAccountList;
	}

	/**
	 * Display accounts by accountNum*
	 **/

	public CurrentAccount getFDAccountByAccountNumber(int getAccountNumber) {
		CurrentAccount ca = daoImpl.getAccountByAccountNumber(getAccountNumber);

		System.out.println("Account Holder Name:" + ca.getAccountHoderName());
		System.out.println("Account Number:" + ca.getAccountNumber());
		System.out.println("OverDraft Limit:" + ca.getOverdraftLimit());
		System.out.println("Balance:" + ca.getBalance());
		return ca;

	}

	/**
	 * 
	 * Delete the account
	 * 
	 ***/
	public void deleteFDAccount(int accountNumber) {

		daoImpl.deleteAccount(accountNumber);
		;

	}

	/***
	 * sort all accounts by account holder names
	 ***/
	public List<CurrentAccount> getAllAccountsSortedByNames() {

		List<CurrentAccount> currentAccountList = daoImpl.getAllAccounts();

		Collections.sort(currentAccountList);

		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = iterator.next();

			System.out.println("Account Holder Name:" + ca.getAccountHoderName());
			System.out.println("Account Number:" + ca.getAccountNumber());
			System.out.println("OverDraft Limit:" + ca.getOverdraftLimit());
			System.out.println("Balance:" + ca.getBalance());
			System.out.println("*********************************************");
		}

		return currentAccountList;
	}

	/***
	 * sort all accounts by balance
	 ***/

	public List<CurrentAccount> getAllPermanentEmployeesSortedByBasicSalary() {

		List<CurrentAccount> currentAccountList = daoImpl.getAllAccounts();

		Collections.sort(currentAccountList, new CurrentAccountComparator());

		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = iterator.next();

			System.out.println("Account Holder Name:" + ca.getAccountHoderName());
			System.out.println("Account Number:" + ca.getAccountNumber());
			System.out.println("OverDraft Limit:" + ca.getOverdraftLimit());
			System.out.println("Balance:" + ca.getBalance());
			System.out.println("*********************************************");
		}

		return currentAccountList;
	}
	/**
	 * add account
	 * */	
	public void addCurrentAccount(CurrentAccount currentAccount) {
		
		boolean isAdded = daoImpl.addAccount(currentAccount);
			
		
		if(!isAdded){
			
			System.out.println("The account already exist");
		}
		else{
			System.out.println("The account successfully added");
			
		}
		
	}
	/**
	 * update account
	 * */
	public void updateCurrentAccount(CurrentAccount currentAccount){
		
		daoImpl.updateAccount(currentAccount);
		
	}


}
