/***
 * Classname:CurrentAccountImp
 * 
 * Description:this class used to achive dao for CurrentAccount
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;
import com.sns.org.model.LoanAccount;
import com.sns.org.model.SBAccount;

/***
 * 
 * CurrentAccountImp class used to achive dao for CurrentAccount
 * 
 * *
 */
public class CurrentAccountImp implements CurrentAccountDAO {
	List currentAccountList;
	Set currentAccountSet;

	/***
	 * 
	 * construcor for CurrentAccountImp class
	 * 
	 * *
	 */
	public CurrentAccountImp() {
		currentAccountList = new ArrayList<CurrentAccount>();
		currentAccountSet = new HashSet<CurrentAccount>();
/*
		CurrentAccount account1 = new CurrentAccount(1510, "Sundhara", 200000, 786765);
		CurrentAccount account2 = new CurrentAccount(1511, "Viji", 80000, 87876);
		CurrentAccount account3 = new CurrentAccount(1512, "Aruthra", 980000, 186765);
		CurrentAccount account4 = new CurrentAccount(1513, "Athvi", 540000, 56765);
		System.out.println("______________________________________________________________");
		currentAccountList.add(account1);
		currentAccountList.add(account2);
		currentAccountList.add(account3);
		currentAccountList.add(account4);
		// TODO Auto-generated constructor stub
	*/
		}

	/**
	 * Display all the accounts*
	 **/
	@Override
	public List<CurrentAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		return currentAccountList;
	}

	/**
	 * Display accounts by accountNum*
	 **/

	@Override
	public CurrentAccount getAccountByAccountNumber(int accountNum) {
		CurrentAccount currentAccount = null;

		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount fd = iterator.next();

			if (fd.getAccountNumber() == accountNum) {
				currentAccount = fd;
			}
		}

		// TODO Auto-generated method stub
		return currentAccount;
	}

	/**
	 * 
	 * Delete the account
	 * 
	 ***/
	@Override
	public void deleteAccount(int accountNum) {
		for (int i = 0; i < currentAccountList.size(); i++) {
			CurrentAccount fd = (CurrentAccount) currentAccountList.get(i);
			if (fd.getAccountNumber() == accountNum) {
				currentAccountList.remove(i);
			}
		}
	}
	/*
	 * 
	 * add new account
	 */
	@Override
	public boolean addAccount(CurrentAccount cda) {
boolean isAdded =  currentAccountSet.add(cda);
		
		if(isAdded){
			currentAccountList.add(cda);
			 
		}
		return isAdded;
	}
	/*
	 * 
	 * update new account
	 */
	@Override
	public void updateAccount(CurrentAccount cda) {
Iterator iterator = currentAccountList.iterator();
		
		
		while(iterator.hasNext()){
			
			CurrentAccount ca =(CurrentAccount)iterator.next();
			
			if(ca.getAccountNumber()==cda.getAccountNumber()){
				
				ca.setAccountHoderName(cda.getAccountHoderName());
				ca.setBalance(cda.getBalance());
				ca.setOverdraftLimit(cda.getOverdraftLimit());
			}
			
			
		}
	}

}
