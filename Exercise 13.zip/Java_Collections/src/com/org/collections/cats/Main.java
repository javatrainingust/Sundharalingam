
/***
 * Classname:Main
 * 
 * Description:To achive Arraylist and sorting
 *
 * Date:05.10.2020
 * 
***/	
package com.org.collections.cats;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
/***
 * main  class used To achive Cats's Arraylist and sorting**/
public class Main {
public static void main(String[] args) {
	List cat = new ArrayList<cats>();
	cats c1=new cats("Sundhar", 3);
	cats c2=new cats("Viji", 1);
	cats c3=new cats("Aruthra", 5);
	cats c4=new cats("Athvi", 4);
	cat.add(c2);
	cat.add(c1);
	cat.add(c3);
	cat.add(c4);
	
	Iterator<cats> i1 =cat.iterator();
	
	while(i1.hasNext()){
		
		cats c = i1.next();
		System.out.println(c);
	}
	
Collections.sort(cat);
System.out.println("After sorting based on albhabetical order of cat name");
Iterator<cats> i2 =cat.iterator();

while(i2.hasNext()){
	
	cats c = i2.next();
	System.out.println(c);
}
}
}
