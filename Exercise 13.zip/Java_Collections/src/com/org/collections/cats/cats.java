
/***
 * Classname:Cats
 * 
 * Description:To achive Arraylist and sorting
 *
 * Date:05.10.2020
 * 
***/	

package com.org.collections.cats;
/***
 * Cats class used To achive Arraylist and sorting**/
public class cats implements Comparable<cats> {

	private String name;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public cats(String name, int age) {
		this.age=age;
		this.name=name;
		// TODO Auto-generated constructor stub
	}
public String toString() {
		
		String details = null;
		
		details = "Cat Name:    "+name+"\t Age :\t"+age;
		
		return details;
	}
@Override
public int compareTo(cats c) {
	
	
	return name.compareTo(c.name);
}
}
