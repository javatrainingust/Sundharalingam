
/***
 * Classname:student
 * 
 * Description:To achive Arraylist and sorting
 *
 * Date:05.10.2020
 * 
***/	
package com.org.collections.student;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/***
 * student class used To achive Arraylist and sorting**/
public class student {

	public static void main(String[] args) {
		ArrayList<String> students = new ArrayList<String>();
		students.add("Sundhar");
		students.add("Viji");
		students.add("Athvi");
		students.add("Aruthra");
	System.out.println("Before Sorting:\n");
		for (String i : students ) {
		      System.out.println(i);	
		      }
		//sorting
	System.out.println("\n\nAfter sort:\n");
	Collections.sort(students);
	for (String i : students ) {
	      System.out.println(i);	
	      }
	}
}
