/***
 * Classname: SBAccountImp
 * 
 * Description:this class used to achive dao for SBAccountImp
 *
 * Date:06.10.2020
 * 
*/package com.sns.org.daoimp;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.sns.org.model.FDAccount;
import com.sns.org.model.LoanAccount;
import com.sns.org.model.SBAccount;

/***
  SBAccountImp class used to achive dao for SBAccountImp
 * 
*/
@Repository
public class SBAccountImp implements SBAccountDAO {
	List sbAccountList;
	private Set sbAccountSet;
	/*SBAccountImp for constructor*/
	 public SBAccountImp() {
		sbAccountList = new ArrayList<SBAccount>();
		sbAccountSet = new HashSet<SBAccount>();
		
		SBAccount sba1=new SBAccount(1510, "Sundhara", 50000);
		SBAccount sba2=new SBAccount(1511, "Aruthra", 90000);
		SBAccount sba3=new SBAccount(1512, "Viji", 99000);
		SBAccount sba4=new SBAccount(1513, "Athvi", 66000);
		sbAccountList.add(sba1);
		sbAccountList.add(sba2);
		sbAccountList.add(sba3);
		sbAccountList.add(sba4);
		 
	 }
		/** 
		 * Display all the accounts*
		 **/
		
	 
		public List<SBAccount> getAllAccounts() {
			// TODO Auto-generated method stub
			return sbAccountList;
		}
		
	 /** 
		 * Display accounts by accountNum*
		 **/
	 
	public SBAccount getAccountByAccountNumber(int accountNum) {
		 SBAccount sbAccount =null;
			
			Iterator<SBAccount>   iterator = sbAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SBAccount sb = iterator.next();
				
				if(sb.getAccountNumber()==accountNum){
					sbAccount=sb;	
				}	
			}	
			
			// TODO Auto-generated method stub
			return sbAccount;
	}

		/**
		 * Delete the account
		 * 
		 * */ 
	
	public void deleteAccount(int accountNum) {
		for(int i=0; i< sbAccountList.size(); i++){		
			FDAccount fd =(FDAccount)sbAccountList.get(i);
			if(fd.getAccountNumber()==accountNum){
				sbAccountList.remove(i);
			}		
			}	
	}
	/*
	 * 
	 * add new account
	 */
	
	public  boolean addAccount(SBAccount fda) {
boolean isAdded =  sbAccountSet.add(fda);
		
		if(isAdded){
			sbAccountList.add(fda);
			 
		}
		return isAdded;
	}
	/*
	 * 
	 * update account
	 */
	
	public void updateAccount(SBAccount sba) {
		// TODO Auto-generated method stub
Iterator iterator = sbAccountList.iterator();
		
		
		while(iterator.hasNext()){
			
			SBAccount sb =(SBAccount)iterator.next();
			
			if(sb.getAccountNumber()==sba.getAccountNumber()){
				sb.setAccountHoderName(sba.getAccountHoderName());
				sb.setBalance(sba.getBalance());
				sb.setRatio(sba.getRatio());
			}
			
			
		}
		
	}
	

}
