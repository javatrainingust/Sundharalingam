package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;

import com.sns.org.servics.FDAccountService;

@Controller
public class FDAccountController {
	@Autowired
	private FDAccountService service;
	
	
	@RequestMapping("/fdAccount")
	
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<FDAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);
		model.addAttribute("fdAccount",accountList );
		
		
		return "fdAccount";
		
	}
	@RequestMapping("/viewFDAccount")
	public String getAccounts(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		FDAccount fd = service.getFDAccountByAccountNumber(Integer.parseInt(accountNumber));
		
		model.addAttribute("keyfd", fd);
		
		
		return "viewFDAccount";
		
		
	}
}
