/***
 * Classname: LoanAccountDAOImpTest
 * 
 * Description:this class used to achive dao for LoanAccountDAOImpTest
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;



import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;
import com.sns.org.model.LoanAccount;
import com.sns.org.servics.FDAccountService;
import com.sns.org.servics.LoanAccountService;

/***
 * LoanAccountDAOImpTest used to achive dao for LoanAccountDAOImpTest *
 */
class LoanAccountDAOImpTest {
	List loanAccountListTest;
	LoanAccountService service= new LoanAccountService();
	/* LoanAccountDAOImpTest constructor */
	public LoanAccountDAOImpTest() {
		loanAccountListTest = new ArrayList<LoanAccount>();
			LoanAccount account1 = new LoanAccount(1510, "Sundhara", 5000, 500, 2);
		LoanAccount account2 = new LoanAccount(1511, "Viji", 5679, 700, 1);
		LoanAccount account3 = new LoanAccount(1512, "Aruthra", 8976, 567, 3);
		LoanAccount account4 = new LoanAccount(1513, "Athvi", 6700, 590, 4);

		loanAccountListTest.add(account1);
		loanAccountListTest.add(account2);
		loanAccountListTest.add(account3);
		loanAccountListTest.add(account4);
		// TODO Auto-generated constructor stub
	}
	/**
	 * Display all the accounts sorted by EMI *
	 **/
	
	@Test
void testGetAllCurrentAccountSortedByEMI() {
		
      String expectedValue = "Sundhara";
		
List<LoanAccount> loanAccount = service.getAllFDAccountsSortedByEMI();
		
	String actualValue = loanAccount.get(0).getAccountHoderName();
		
	assertEquals(expectedValue, actualValue);
		
	}
	/**
	 * Display all the accounts sorted by names *
	 **/ @Test
	void testGetAllCurrentAccountSortedByNames() {
			
			String expectedValue = "Sundhara";
			
			List<LoanAccount> loanAccount = service.getAllAccountsSortedByNames();
			
			String actualValue = loanAccount.get(0).getAccountHoderName();
			
		assertEquals(expectedValue, actualValue);
		}
	/**
	 * Display all the accounts*
	 **/
/*
	@Test
	void testGetAllAccounts() {
		List<LoanAccount> expectedList = new ArrayList<LoanAccount>();
		LoanAccountDAOImp daoImp = new LoanAccountDAOImp();
		expectedList = daoImp.getAllAccounts();
		assertEquals(expectedList.size(), loanAccountListTest.size());
	}

	/**
	 * Display accounts by accountNum*
	 **/

/*	@Test
	void testGetAccountByAccountNumber() {
		LoanAccount expected = (LoanAccount) loanAccountListTest.get(0);
		LoanAccountDAOImp daoImp = new LoanAccountDAOImp();
		LoanAccount actual = daoImp.getAccountByAccountNumber(1510);
		assertEquals(expected.getAccountHoderName(), actual.getAccountHoderName());

	}

/* Delete the account *//*	
	@Test
	void testDeleteAccount() {
		List<LoanAccount> expected = new ArrayList<LoanAccount>();
		LoanAccountDAOImp daoImp = new LoanAccountDAOImp();
		daoImp.deleteAccount(1513);
		expected = daoImp.getAllAccounts();
		assertEquals(expected.size(), loanAccountListTest.size() - 1);
	}
*/
/*	@Test
	void testAddAccount() {
		
		int expected=4;
		service.addloanAccount(new LoanAccount(1510, "Sundhara", 5000, 500, 2));
		service.addloanAccount(new LoanAccount(1511, "Viji", 5679, 700, 1));
		service.addloanAccount(new LoanAccount(1512, "Aruthra", 8976, 567, 3));
		service.addloanAccount(new LoanAccount(1513, "Athvi", 6700, 590, 4));
		List actual=service.getAllAccounts();
		assertEquals(expected, actual.size());
	}*/
	/*
	 * update account**/
	/*@Test
	void testUpdateAccount() {
		float expected=5000;
		LoanAccountDAOImp daoImp = new LoanAccountDAOImp();
		LoanAccount actual = daoImp.getAccountByAccountNumber(1510);
		
		assertEquals(expected, actual.getLoanOutStanding());
	}*/
	
}
