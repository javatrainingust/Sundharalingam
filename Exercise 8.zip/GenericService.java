package com.org.genericService;

import com.org.Model.Account;
import com.org.Model.CurrentAccount;
import com.org.Model.FDAccount;
import com.org.Model.SBAccount;

public class GenericService extends Account{
public static void main(String[] args) {
	Account acc=new Account();
	FDAccount fd=new FDAccount();
	SBAccount sb=new SBAccount();
	
	Account [] acca = { new  Account() , fd, sb};
for (Account a:acca) {
	a.interestCalculator();	
	if(a instanceof FDAccount){
		FDAccount fda=(FDAccount)a;
	//fda.autoRenewal(1);
	}
}

}
}
