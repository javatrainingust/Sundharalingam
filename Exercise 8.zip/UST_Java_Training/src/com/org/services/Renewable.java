package com.org.services;

public interface Renewable {

	public void autoRenewal(int tenure);
}
