package com.org.services;

import com.org.Model.FDAccount;

public class AutomaticRenewableService {
	
	public static void main(String[] args) {
	
	Renewable r = new FDAccount();
	r.autoRenewal(6);
	}

}
