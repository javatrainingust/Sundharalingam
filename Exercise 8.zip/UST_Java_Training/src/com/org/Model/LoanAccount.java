package com.org.Model;

public class LoanAccount extends Account {
private float EMI;
public float getEMI() {
	System.out.println("Total EMI :"+EMI);
	return EMI;
	
}
public void setEMI(float eMI) {
	EMI = eMI;
}
public float getLoanOutStanding() {
	System.out.println("LoanOutStanding:"+LoanOutStanding);
	return LoanOutStanding;
	
}
public void setLoanOutStanding(float loanOutStanding) {
	LoanOutStanding = loanOutStanding;
}
public int getTenture() {
	System.out.println("Tenture:"+Tenture);
	return Tenture;
}
public void setTenture(int tenture) {
	Tenture = tenture;
}
private float LoanOutStanding;
private int Tenture;

}
