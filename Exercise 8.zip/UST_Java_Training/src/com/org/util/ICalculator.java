package com.org.util;

public interface ICalculator {

	public float intrestCalculate(float p, int n, float r) ;
	public float intrestCalculate(double p,int n);
}
