package com.sns.org.about;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AboutMeController {

	@RequestMapping("/hobbies")
	public String showPage() {
		return "hobbies";
}
}
