package exersize;

public class B extends A {
private int a=123;

/*public void rollBackA() {
	 a=super.getA();
}
public void setA(int value) {
	a = value;
}
public B() {
	a=2222;
	System.out.println("Constructor B");
	System.out.println("b="+b);
	b=3.141;
	System.out.println("b="+b);
}*/

public void display() {
	System.out.printf("a in B=%d\n",a);
}
}
