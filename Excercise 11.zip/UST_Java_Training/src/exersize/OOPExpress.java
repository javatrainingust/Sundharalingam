/**
 * 
 */
package exersize;

/**
 * @author Vijayalakshmi
 *
 */
public class OOPExpress {
	static int a=555;
public static void main(String[] args) {
	A objA=new A();
	B objB1=new B();
	A objB2=new B();
	C objC1=new C();
	B objc2=new C();
	A objc3=new C();
	objA.display();
	objB1.display();
	objB2.display();
	objC1.display();
	objc2.display();
	objc3.display();
	
	
}
}
