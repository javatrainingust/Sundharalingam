package exersize;

public class C extends B{
private int a=543;

public void display() {
	System.out.printf("a in C=%d\n",a);
}
}
