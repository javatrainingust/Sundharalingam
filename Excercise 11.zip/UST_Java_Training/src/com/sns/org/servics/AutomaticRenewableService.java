package com.sns.org.servics;

import com.sns.org.model.FDAccount;

public class AutomaticRenewableService {
	
	public static void main(String[] args) {
	
	Renewable r = new FDAccount();
	r.autoRenewal(6);
	}

}
