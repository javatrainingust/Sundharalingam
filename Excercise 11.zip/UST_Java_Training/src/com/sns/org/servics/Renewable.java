package com.sns.org.servics;

public interface Renewable {

	public void autoRenewal(int tenure);
}
