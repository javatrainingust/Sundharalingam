package com.sns.org.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CurrentAccountTest {

	@Test
	void testGetOverdraftLimit() {
	CurrentAccount ca=new CurrentAccount();
	ca.setOverdraftLimit(3000);
	float actual=ca.getOverdraftLimit();
	float expected=3000;
	assertEquals(expected, actual);
	}

}
