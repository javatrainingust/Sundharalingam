package com.sns.org.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FDAccountTest {

	FDAccount fd=new FDAccount();


	@Test
	void testGetFixedDepositAmount() {
		fd.setFixedDepositAmount(5000);
		float actual=fd.getFixedDepositAmount();
		float expected=5000;
		assertEquals(expected, actual);
	}

}
