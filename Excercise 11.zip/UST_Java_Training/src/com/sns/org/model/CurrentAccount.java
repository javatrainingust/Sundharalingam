/***
 * Classname:CurrentAccount
 * 
 * Description:/***sub class for account derived from account class . This class used to maintain a Current Account  
 *
 * Date:30.09.2020
 * 
**/	
package com.sns.org.model;
/***sub class for account derived from account class **/	
public class CurrentAccount extends Account{
private int overDraftLimit;
/***get the limit of over draft**/	
public int getOverdraftLimit() {
	System.out.println("OverDraft Limit:"+overDraftLimit);
return overDraftLimit;
	}
/***set the limit of over draft**/	
public void setOverdraftLimit(int overDraftLimit) {
	this.overDraftLimit = overDraftLimit;
}
}
