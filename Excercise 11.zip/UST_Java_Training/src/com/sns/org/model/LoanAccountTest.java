package com.sns.org.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LoanAccountTest {

	@Test
	void testGetemi() {
		LoanAccount la=new LoanAccount();
		la.setEmi(2000);;
		float actual=la.getEmi();
		float expected=2000;
		assertEquals(expected, actual);
	}

}
