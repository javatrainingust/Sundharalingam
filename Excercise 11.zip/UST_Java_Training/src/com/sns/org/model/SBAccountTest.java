/***
 * Classname:CalculatorTest
 * 
 * Description: Junit handling a SBA Account  
 *
 * Date:01.10.2020
 * 
**/
package com.sns.org.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
/* * Description: Junit handling a SBA Account*/
class SBAccountTest {

	@Test
	void testWithdrawMoney() {
		SBAccount sba=new SBAccount();
		sba.setBalance(5000);
		sba.withdrawMoney(100);
		float actual=sba.getBalance();
		float expected=4900;
		assertEquals(expected, actual);
	}

}
