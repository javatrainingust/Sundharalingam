package com.org.genericService;

import com.org.Model.Account;
import com.org.Model.CurrentAccount;
import com.org.Model.FDAccount;
import com.org.Model.SBAccount;

public class GenericService extends Account{
public static void main(String[] args) {
	SBAccount aba=new SBAccount(5000,2);
}


}
