package com.org.Model;

import com.org.util.InterestCalculator;

public class SBAccount extends Account {
	public SBAccount() {
		System.out.println("SBAccount Class with no arg");
	}
	public SBAccount(float balance, int year) {
		this();
		//super();
		System.out.println("SBA Account Class With arg\n");
	}
	private float Balance=5000;
	private int year=1;
	private float ratio=5;
	public int getYear() {
		System.out.println("Year:"+year);
		return year;
	}
	public void setYear(int year) {
	
		this.year = year;
	}
	public float getRatio() {
		System.out.println("Ratio of Interest:"+ratio+"%");
		return ratio;
	}
	public void setRatio(double d) {
		this.ratio = (float) d;
	}
	private InterestCalculator interestcalculator=new InterestCalculator(); 
	public float getBalance() {
		System.out.println("Balance:"+Balance);
		return Balance;
	}
	public void setBalance(float balance) {
		Balance = balance;
	}
	public void withdrawMoney(int Amount) {
		System.out.println("Withdraw Amount:"+Amount);
		if(Balance>Amount) {
			Balance=Balance-Amount;
			System.out.println("Balance:"+Balance);
		}
		else {
			System.out.println("You don't have enaugh money");
		}
	}
	public void interestCalculator() {
	float interest=interestcalculator.intrestCalculate(Balance, year, ratio);;
	System.out.println("Saving Account Interest:"+interest);
	System.out.println("Total:"+(interest+Balance));
}


}
