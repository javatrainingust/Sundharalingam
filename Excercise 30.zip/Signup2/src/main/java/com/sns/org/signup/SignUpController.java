package com.sns.org.signup;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class SignUpController {
	@RequestMapping("/showForm")
	public String showForm(Model theModel) {
		
		// create a student object
		Signup theSignUp = new Signup();
		
		theSignUp.setUser("1510");
		theSignUp.setUserID("nrsundaralingam@gmail.com");
		theSignUp.setPass1("suman1510");
		theSignUp.setConfirmPassowrd("suman1510");
		
		
		
		// add student object to the model
		theModel.addAttribute("signup", theSignUp);
		
		return "Signup";
	}
	
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("signup") Signup theSignUp) {
		
		// log the input data
		System.out.println("Sign Up User Name: " + theSignUp.getUser()+ " " + "signup successful");
		
		return "confirmSignUp";
	}
	
}
