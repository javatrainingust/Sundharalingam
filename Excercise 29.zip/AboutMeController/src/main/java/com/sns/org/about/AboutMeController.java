package com.sns.org.about;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AboutMeController {

	@RequestMapping("/myhobbies")
	public String showPage() {
		return "aboutMe";
}
	@RequestMapping("/processForm")
	public String process(@RequestParam("hobbies") String theName, Model model) {
		// convert the data to all caps
				theName = theName.toUpperCase();
				
				// create the message
				String result = "My Hubbies are  " + theName;
				
				// add message to the model
				model.addAttribute("message", result);
						
				
		return "myHobbies";
	}
}
