/***
 * Classname:LoanAccount
 * 
 * Description:This is a child class of Account Class. This class used to handle Loan Account  
 *
 * Date:30.09.2020
 * 
**/	
package com.sns.org.model;
/**This class used to handle Loan Account **/	
public class LoanAccount extends Account {
	private float emi;
	private float loanOutStanding;
	private int tenture;

/**To Set EMI**/	
public float getEmi() {
		return emi;
}
/**To Get EMI**/	
public void setEmi(float emi) {
		this.emi = emi;
}

/**To Get Loan OutStanding of EMI**/	
public float getLoanOutStanding() {
	System.out.println("LoanOutStanding:"+loanOutStanding);
	return loanOutStanding;	
}
/**To Set Loan OutStanding of EMI**/	
public void setLoanOutStanding(float loanOutStanding) {
	loanOutStanding = this.loanOutStanding;
}
/**To Get Loan tenture of EMI**/	
public int getTenture() {
	System.out.println("Tenture:"+tenture);
	return tenture;
}
/**To Set Loan tenture of EMI**/	
public void setTenture(int tenture) {
	tenture = tenture;
}


}
