package exersize;

public class A {
int a=100;
/*public A() {
	//System.out.println("in Cons A---");
	//System.out.println("a="+a);
	a=333;
	//System.out.println("a="+a);
}
public int getA() {
	return a;
}

public void setA(int value) {
	a = value;
}*/

public void display() {
	System.out.printf("a in A=%d\n",a);
}
}
