/***
 * Class: Guitar
 * Description: This class used to Implement Instrument interface 
 * Date:12-10-2020
 */
package com.org.sns.spring;
/***
 * Guitar class used to Implement Instrument interface 
 * */
public class Guitar implements Instrument{
	/**
	 * constructor
	 * */
public Guitar(){
	System.out.println("Guitar constructor");
}

/***
 * Play method displays Playing Guitar
 */

public void play() {
	// TODO Auto-generated method stub
	System.out.println(" Guitar is Playing ");
}

}
