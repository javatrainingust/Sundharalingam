/***
 * Class:SpringDemo
 * Description: This class used to call organize and singer beans 
 * Date:12-10-2020
 */
package com.org.sns.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * SpringDemo class used to call organize and singer beans
 */
public class SpringDemo {
	/**
	 * Main method
	 */
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContextV3.xml");

		Organizers orgenizer = context.getBean("welcomeMsg", Organizers.class);

		orgenizer.sayGreetings();
		/*
		 * Singer singer = context.getBean("singer", Singer.class); singer.perform();
		 */

	}
}
