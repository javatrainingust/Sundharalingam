/***
 * Instrument
 * Description: This interface used to to define play instrument.
 * Date:12-10-2020
 */
package com.org.sns.spring;
/***
 * Instrument interface used to to define play instrument.*/
public interface Instrument {
	public void play();
}
