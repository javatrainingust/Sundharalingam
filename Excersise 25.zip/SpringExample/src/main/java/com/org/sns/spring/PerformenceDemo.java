/***
 * Class:PerformenceDemo
 * Description: This is a spring example about Spring demo
 * Date:12-10-2020
*/
package com.org.sns.spring;
import org.springframework.context.support.ClassPathXmlApplicationContext;
/***
 * PerformenceDemo is a spring example about Spring demo
*/
public class PerformenceDemo {
/***
 * main method starting
 * */
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		Instrumentalist instrumentalist = context.getBean("Keyboard", Instrumentalist.class);

		instrumentalist.perform();

	}

}
