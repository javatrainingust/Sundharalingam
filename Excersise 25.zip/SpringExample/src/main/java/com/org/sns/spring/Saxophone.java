/***
 * Class: Saxophone
 * Description: This is a Saxophone class used to imolement Instrument
 * Date:12-10-2020
*/
package com.org.sns.spring;

import org.springframework.stereotype.Component;

/***
  Saxophone is a Saxophone class used to implement Instrument
*/
@Component
public class Saxophone implements Instrument {
	/**constructor */
public Saxophone(){
	System.out.println("Saxophone Constructor");
}
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Saxophone is playing");
	}

}
