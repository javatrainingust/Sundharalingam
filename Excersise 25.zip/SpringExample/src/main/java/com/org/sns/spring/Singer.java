/***
 * class :Singer
 * Description: This interface used to to define performer. it implement singer interface
 * Date:12-10-2020
 */
package com.org.sns.spring;
/***
 * Performer interface used to to define performer. it implement singer interface
 */
public class Singer implements Performer {
	
private String song;
/**
 * constructor
 * **/
	public Singer(String song){
		this.song=song;
		System.out.println("Singer Constructor:"+song);
	}
	
	/***
	 * method defanition
	 * **/
	public void perform() {
		// TODO Auto-generated method stub
		System.out.println("Song Performed by:"+song+"");
	}

	public void perform(Saxophone sphones) {
		// TODO Auto-generated method stub
		
	}

	
}
