/***
 * class: MainMethod
 * Description: This class used to to call spring
 * Date:12-10-2020
 */
package com.org.sns.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;
/***
 *  MainMethod This class used to to call spring
 */
public class MainMethod {
	/***
	 * main method
	 * */
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContextV2.xml");

		OneManBand oneManBand = context.getBean("OneManBand",OneManBand.class);
		
		oneManBand.perform();
	}
}
