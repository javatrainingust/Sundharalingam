/***
 * class: PredicateDemo
 * 
 * Description:this class used to implement Predicate for check number is greater than 50 or not
 *
 * Date:08.10.2020
 * 
*/
package com.sns.fuctional.Predicate;

import java.util.function.Predicate;
/***
 *PredicateDemo class used to implement Predicate for check number is greater than 50 or not
*/
public class PredicateDemo {
/**
 * main method starting from here
 * */
	public static void main(String[] args) {
		
		Predicate <Integer> checkValue = (i) -> {
		      
			 if(i>=50) {
				 
				 return true;
				 
			 }
			 else {
				 
				 return false;
			 }
			
		};
		
		System.out.println("check value greater than 50 or not: "+checkValue.test(78));
	}

}
