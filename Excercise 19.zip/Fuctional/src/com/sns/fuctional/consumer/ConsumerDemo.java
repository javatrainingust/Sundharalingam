/***
 * class: ConsumerDemo
 * 
 * Description:this class used to implement consumer for convert every string to uppercase
 *
 * Date:08.10.2020
 * 
*/package com.sns.fuctional.consumer;

import java.util.function.Consumer;
/***
 * ConsumerDemo class used to implement consumer for convert every string to uppercase
 */
public class ConsumerDemo {
/**
 * 
 * main method starting**/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer <String> consumer = (s) -> {
		      
			System.out.println("Before convertion:"+s);
		System.out.println("After convertion:"+s.toUpperCase());
			
		};
		
		consumer.accept("suman");
	}

}
