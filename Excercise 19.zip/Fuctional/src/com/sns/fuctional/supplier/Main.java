/***
 * class: Main
 * 
 * Description:this class used to implement supplier for random number
 *
 * Date:08.10.2020
 * 
*/
package com.sns.fuctional.supplier;

import java.util.function.Supplier;

/***
  Main class used to implement supplier for random number
 * 
*/
public class Main {
/**
 * main method starting here**/
	public static void main(String[] args) {
		
		Supplier randomNumberSupplier = () -> Math.random()*100;
		System.out.println("First Random number by lamda Expression:"+randomNumberSupplier.get());
		SupplierDemo impl = new SupplierDemo();
		
		System.out.println("Second Random Number form interface : "+impl.get());

	}

}
