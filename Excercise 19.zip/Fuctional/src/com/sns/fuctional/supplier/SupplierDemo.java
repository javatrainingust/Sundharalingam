/***
 * class: SupplierDemo
 * 
 * Description:this class used to implement supplier interface
 *
 * Date:08.10.2020
 * 
*/
package com.sns.fuctional.supplier;

import java.util.function.Supplier;

/***
 *SupplierDemo class used to implement supplier interface
 *
 * 
*/
public class SupplierDemo implements Supplier {
	/**
	 * 
	 * supplier interface implement get method**/
@Override
public Object get() {
	// TODO Auto-generated method stub
	return Math.random()*100;
}
}
