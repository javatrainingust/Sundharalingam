/***
 * class: FunctionalDemo
 * 
 * Description:this class used to implement function interface for convert every string to uppercase
 *
 * Date:08.10.2020
 * 
*/
package com.org.fuctional.functional;

import java.util.function.Function;
/***
 * FunctionalDemo class used to implement function interface for convert every string to uppercase
*/
public class FunctionalDemo {
/**
 * main method starting */
public static void main(String arg[]) {
		
	String s="suman";
		
		Function<String,String> strConversion = (str) -> {
		      
			 return str.toUpperCase();
			
		};
		
		System.out.println("Before convertion:"+strConversion.apply(s));
		System.out.println("After Convertion to Upper case:"+strConversion.apply(s));
	
	}
}
