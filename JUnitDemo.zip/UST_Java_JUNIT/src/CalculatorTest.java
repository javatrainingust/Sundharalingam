import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	void testAdd() {
		assertEquals(7, new Calculator().add(4, 3));
	}

	@Test
	void testSubtract() {
		assertEquals(1, new Calculator().subtract(4, 3));
	}

}
