/***
 * Classname: InsufficentBalanceException
 * 
 * Description:This class used for new InsufficentBalanceException type of exception 
 *
 * Date:09.10.2020
 * 
**/
package com.sns.org.exception;

/***
 * InsufficentBalanceException class used for new InsufficentBalanceException
 * type of exception
 * 
 **/
public class InsufficentBalanceException extends Exception {
	int balance;

	/**
	 * constructor
	 */
	public InsufficentBalanceException(int balance) {

		this.balance = balance;
	}

	/**
	 * tostrring method
	 */
	public String toString() {

		return "You don't have enaugh money to withdraw. you have given " + balance + " Rupees";
	}
}
