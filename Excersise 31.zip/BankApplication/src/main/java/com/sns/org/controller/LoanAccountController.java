package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import com.sns.org.servics.LoanAccountService;
import com.sns.org.model.LoanAccount;

@Controller
public class LoanAccountController {
	@Autowired
	private LoanAccountService service;
	
	
	@RequestMapping("/loanAccount")
	
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<LoanAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);
		model.addAttribute("loanAccount",accountList );
		
		
		return "loanAccount";
		
	}
}
