/***
 * Classname:GenericService
 * 
 * Description:to call generic service call
 *
 * Date:30.09.2020
 * 
***/		
package com.sns.org.genericservice;

import com.sns.org.model.Account;
import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;
import com.sns.org.model.SBAccount;

public class GenericService extends Account{
	//main method starting Here
public static void main(String[] args) {
	SBAccount aba=new SBAccount(5000,2);
}


}
