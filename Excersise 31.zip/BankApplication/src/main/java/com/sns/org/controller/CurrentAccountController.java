package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import com.sns.org.model.CurrentAccount;
import com.sns.org.servics.CurrentAccountService;

@Controller
public class CurrentAccountController {
	@Autowired
	private CurrentAccountService service;
	
	
	@RequestMapping("/caAccount")
	
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<CurrentAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);
		model.addAttribute("caAccount",accountList );
		
		
		return "caAccount";
		
	}
}
