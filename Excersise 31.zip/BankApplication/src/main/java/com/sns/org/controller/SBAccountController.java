package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sns.org.model.SBAccount;

import com.sns.org.servics.SBAccountService;

@Controller
public class SBAccountController {
	@Autowired
	private SBAccountService service;
	
	
	@RequestMapping("/sbAccount")
	
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<SBAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);
		model.addAttribute("sbAccount",accountList );
		
		
		return "sbAccount";
		
	}
}
