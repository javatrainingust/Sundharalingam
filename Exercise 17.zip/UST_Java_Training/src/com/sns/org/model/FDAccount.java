/***
 * Classname:FDAccount
 * 
 * Description:This is a child class of Account Class. This class used to handle a Fixed Deposite  
 *
 * Date:30.09.2020
 * 
*/
package com.sns.org.model;

import java.util.Calendar;
import java.util.Date;


import com.sns.org.util.InterestCalculator;
/**This class used to handle a Fixed Deposite  */
public class FDAccount extends Account implements Comparable<FDAccount> {
	private int tenture=1;
	private String autoRenewal;
	private float fixedDepositAmount=50000;
	private int accountNumber;
	private String accountHoderName;
	public FDAccount(int accountNumber, String accountHoderName, float fixedDepositAmount,int tenture,float ratio) {
		this.accountNumber=accountNumber;
		this.accountHoderName=accountHoderName;
		this.fixedDepositAmount=fixedDepositAmount;
		this.ratio=ratio;
		this.tenture=tenture;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHoderName() {
		return accountHoderName;
	}
	public void setAccountHoderName(String accountHoderName) {
		this.accountHoderName = accountHoderName;
	}
	
	public void setRatio(float ratio) {
		this.ratio = ratio;
	}
	private float ratio=7;
	private Date maturityDate;
	private InterestCalculator interestcalculator=new InterestCalculator(); 
	
	/**To Get Tenture of Fixed Deposite  */	
	public int getTenture() {
		//System.out.println("Tenture:"+tenture+"Years");
		return tenture;
	}
	/**To Set Tenture of Fixed Deposite  */	
	public void setTenture(int tenture) {
		this.tenture = tenture;
	}
	/**To Get autoRenewal of Fixed Deposite  */	
	public String getAutoRenewal() {
		System.out.println("AutoRenuwal :"+autoRenewal);
		return autoRenewal;
	}
	/**To Set autoRenewal of Fixed Deposite  */	
	public void setAutoRenewal(String autoRenewal) {
		this.autoRenewal = autoRenewal;
	}
	
	/**To Get getMaturityDate of Fixed Deposite  */	
	public Date getMaturityDate() {
		System.out.println("Maturity Date:"+maturityDate);
		return maturityDate;
	}
	/**To Get setMaturityDate of Fixed Deposite  */	
	public void setMaturityDate(Date dateSpecified) {
		
		this.maturityDate = dateSpecified;
	}
	/**To Get get Ratio of Fixed Deposite  */	
	public float getRatio() {
		//System.out.println("Ratio:"+ratio+"%");
		return ratio;
	}
	/**To Get set FD Amount of Fixed Deposite  */	
	public float getFixedDepositAmount() {
		//System.out.println("FD Amount:"+fixedDepositAmount);
			return fixedDepositAmount;
		}
	/**To Get set FD Amount of Fixed Deposite  */	
		public void setFixedDepositAmount(float fixedDepositAmount) {
			this.fixedDepositAmount = fixedDepositAmount;
		}
		/**To Get Set Ratio of Fixed Deposite  */	
	public void setRatio(double d) {
		this.ratio = (float) d;
	}
	/***overriding method for calculate interest*/
	public void interestCalculator() {
		float interest=interestcalculator.intrestCalculate(fixedDepositAmount, tenture, ratio);;
		System.out.println("FD Simple Interest:"+interest);
		System.out.println("Total:"+(interest+fixedDepositAmount));
	}
	/*** renew when meet the maturity date*//*
	@Override
	public void autoRenewal(int tenuree) {
		if (autoRenewal=="Yes") {
			
			
				System.out.println("AutoRewal:"+"Yes");	// TODO Auto-generated method stub
				System.out.println("tenuree:"+tenuree+"years");	// TODO Auto-generated method stub
				System.out.println("Maturity Date not yet Arraived");
				//c.add(Calendar.YEAR, tenuree);
				//System.out.println("Maturity Date:"+c.getTime());
			
				
		}else {
			System.out.println("AutoRewal:"+"Yes");	// TODO Auto-generated method stub
			System.out.println("tenuree:"+tenuree+"years");	// TODO Auto-generated method stub
			
		
			
	}*/
	/*
	 * 
	 * override compareto method
	 */
	@Override
	public int compareTo(FDAccount o) {
		// TODO Auto-generated method stub
		return this.accountHoderName.compareTo(o.getAccountHoderName());
	}
	
}
