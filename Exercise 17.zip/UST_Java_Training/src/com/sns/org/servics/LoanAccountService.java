/***
 * class: LoanAccountService
 * 
 * Description:this class used to implement LoanAccountService
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.servics;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.sns.org.daoimp.LoanAccountDAO;
import com.sns.org.daoimp.LoanAccountDAOImp;
import com.sns.org.daoimp.SBAccountDAO;
import com.sns.org.daoimp.SBAccountImp;
import com.sns.org.model.FDAccount;
import com.sns.org.model.LoanAccount;
import com.sns.org.model.SBAccount;

/***
 * LoanAccountService class used to implement LoanAccountService
 * 
 */
public class LoanAccountService {
	/* contructor */
	LoanAccountDAO daoImpl;

	public LoanAccountService() {
		// TODO Auto-generated constructor stub

		daoImpl = new LoanAccountDAOImp();

	}

	/**
	 * Display all the accounts*
	 **/

	public List<LoanAccountDAO> getAllAccounts() {
		List l = null;
		List LoanAccountList = daoImpl.getAllAccounts();

		Iterator<LoanAccount> iterator = LoanAccountList.iterator();

		while (iterator.hasNext()) {

			LoanAccount la = iterator.next();

			System.out.println("Loan Id: " + la.getAccountNumber());
			System.out.println("Loan Account Holder Name: " + la.getAccountHoderName());
			System.out.println("Loan Amount: " + la.getLoanOutStanding());
			System.out.println("EMI:" + la.getEmi());
			System.out.println("Tenture:" + la.getTenture());
			System.out.println("************************************************");

		}

		return l;
	}

	/**
	 * Display accounts by accountNum*
	 **/
	public LoanAccount getLoanAccountByAccountNumber(int getAccountNumber) {
		LoanAccount la = daoImpl.getAccountByAccountNumber(getAccountNumber);
		System.out.println("Loan Id: " + la.getAccountNumber());
		System.out.println("Loan Account Holder Name: " + la.getAccountHoderName());
		System.out.println("Loan Amount: " + la.getLoanOutStanding());
		System.out.println("EMI:" + la.getEmi());
		System.out.println("Tenture:" + la.getTenture() + " Years");
		return la;

	}

	/* Delete the account */
	public void deleteLoanAccount(int accountNumber) {

		daoImpl.deleteAccount(accountNumber);
		;

	}

	/***
	 * sort all accounts by account holder names***/
	public List<LoanAccount>	getAllAccountsSortedByNames(){
		
		
		List<LoanAccount> loanAccountList = daoImpl.getAllAccounts();
		
		Collections.sort(loanAccountList);
		
		
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		
		while(iterator.hasNext()){
			
			LoanAccount la = iterator.next();
			

			System.out.println("Loan Id: " + la.getAccountNumber());
			System.out.println("Loan Account Holder Name: " + la.getAccountHoderName());
			System.out.println("Loan Amount: " + la.getLoanOutStanding());
			System.out.println("EMI:" + la.getEmi());
			System.out.println("Tenture:" + la.getTenture() + " Years");
			
			System.out.println("*********************************************");
			}			
		
		
		
		return loanAccountList;
	}
	/***
	 * sort all accounts by EMI***/
		
public List<LoanAccount>	getAllFDAccountsSortedByEMI(){
		
	List<LoanAccount> loanAccountList = daoImpl.getAllAccounts();
		
		Collections.sort(loanAccountList,new LoanAccountComparator());
		
		
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		
		while(iterator.hasNext()){
			
		LoanAccount la = iterator.next();
			

			System.out.println("Loan Id: " + la.getAccountNumber());
			System.out.println("Loan Account Holder Name: " + la.getAccountHoderName());
			System.out.println("Loan Amount: " + la.getLoanOutStanding());
			System.out.println("EMI:" + la.getEmi());
			System.out.println("Tenture:" + la.getTenture() + " Years");
			
			System.out.println("*********************************************");
			}			
		
		
		
		return loanAccountList;
	}
		

}

