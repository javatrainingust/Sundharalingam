/***
 * class: FDAccountComparator
 * 
 * Description:this class used to sort FDAccount by comparator 
 *
 * Date:07.10.2020
 * 
*/
package com.sns.org.servics;

import java.util.Comparator;

import com.sns.org.model.FDAccount;
/***
 *FDAccountComparator class used to sort FDAccount by comparator 
 *
*/
public class FDAccountComparator implements Comparator<FDAccount> {
/**
 * main method*/
	@Override
	public int compare(FDAccount one, FDAccount two) {
		// TODO Auto-generated method stub
		return (int)(one.getFixedDepositAmount()-two.getFixedDepositAmount());
		}



}
