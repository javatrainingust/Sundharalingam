/***
 * Classname:FDADAOImpTest
 * 
 * Description:this class used to achive dao for FDADAOImpTest
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sns.org.model.FDAccount;

/***
 * 
 * FDADAOImpTest class used to achive dao for FDADAOImpTest
 * 
 ***/
public class FDADAOImp implements FDADAO {
	List fdaAccountList;

	/* constructor for FDADAOImpTest */
	public FDADAOImp() {
		fdaAccountList = new ArrayList<FDAccount>();

		FDAccount fda1 = new FDAccount(1510, "Sundhara", 50000, 2, 8);
		FDAccount fda2 = new FDAccount(1511, "Viji", 80000, 2, 8);
		FDAccount fda3 = new FDAccount(1512, "Aruthra", 90000, 2, 8);
		FDAccount fda4 = new FDAccount(1513, "Athvi", 20000, 2, 8);
		fdaAccountList.add(fda1);
		fdaAccountList.add(fda2);
		fdaAccountList.add(fda3);
		fdaAccountList.add(fda4); // TODO Auto-generated constructor stub
	}

	/**
	 * Display all the accounts*
	 **/

	@Override
	public List<FDAccount> getAllAccounts() {
		return fdaAccountList;

	}

	/**
	 * Display accounts by accountNum*
	 **/

	@Override
	public FDAccount getAccountByAccountNumber(int accountNum) {
		FDAccount fdAccount = null;

		Iterator<FDAccount> iterator = fdaAccountList.iterator();

		while (iterator.hasNext()) {

			FDAccount fd = iterator.next();

			if (fd.getAccountNumber() == accountNum) {
				fdAccount = fd;
			}
		}

		// TODO Auto-generated method stub
		return fdAccount;
	}

	/* Delete the account */
	@Override
	public void deleteAccount(int accountNum) {
		for (int i = 0; i < fdaAccountList.size(); i++) {
			FDAccount fd = (FDAccount) fdaAccountList.get(i);
			if (fd.getAccountNumber() == accountNum) {
				fdaAccountList.remove(i);
			}
		}
	}

	@Override
	public boolean addAccount(FDAccount fda) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void updateAccount(FDAccount fda) {
		// TODO Auto-generated method stub

	}

}
