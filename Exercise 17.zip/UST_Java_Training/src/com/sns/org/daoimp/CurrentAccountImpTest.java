/***
 * Classname:CurrentAccountImpTest
 * 
 * Description:this class used to achive dao for CurrentAccountImpTest
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.sns.org.model.CurrentAccount;

/*** CurrentAccountImpTest class used to achive dao for CurrentAccountImpTest */
class CurrentAccountImpTest {
	List currentAccountImpTest;

	/***
	 * constructor for CurrentAccountImpTest
	 *
	 ***/
	public CurrentAccountImpTest() {
		currentAccountImpTest = new ArrayList<CurrentAccount>();
		CurrentAccount account1 = new CurrentAccount(1510, "sundhara", 200000, 786765);
		CurrentAccount account2 = new CurrentAccount(1511, "Viji", 80000, 87876);
		CurrentAccount account3 = new CurrentAccount(1512, "Aruthra", 980000, 186765);
		CurrentAccount account4 = new CurrentAccount(1513, "Athvi", 540000, 56765);
		currentAccountImpTest.add(account1);
		currentAccountImpTest.add(account2);
		currentAccountImpTest.add(account3);
		currentAccountImpTest.add(account4);

	}

	/**
	 * Display all the accounts*
	 **/

	@Test
	void testGetAllAccounts() {
		List<CurrentAccount> expected = new ArrayList<CurrentAccount>();
		CurrentAccountImp daoImp = new CurrentAccountImp();
		expected = daoImp.getAllAccounts();
		assertEquals(expected.size(), currentAccountImpTest.size());

	}

	/**
	 * Display accounts by accountNum*
	 **/

	@Test
	void testGetAccountByAccountNumber() {
		CurrentAccount expected = (CurrentAccount) currentAccountImpTest.get(0);
		CurrentAccountImp daoImp = new CurrentAccountImp();
		CurrentAccount actual = daoImp.getAccountByAccountNumber(1510);
		assertEquals(expected.getAccountHoderName(), actual.getAccountHoderName());

	}

	/**
	 * 
	 * Delete the account *
	 * 
	 */
	@Test
	void testDeleteAccount() {
		List<CurrentAccount> expected = new ArrayList<CurrentAccount>();
		CurrentAccountImp daoImp = new CurrentAccountImp();
		daoImp.deleteAccount(1513);
		expected = daoImp.getAllAccounts();
		assertEquals(expected.size(), currentAccountImpTest.size() - 1);
	}

}
