package com.sns.org.signup;

public class Signup {
private String user;
private String pass1;
private String confirmPassowrd;
public String getConfirmPassowrd() {
	return confirmPassowrd;
}
public void setConfirmPassowrd(String confirmPassowrd) {
	this.confirmPassowrd = confirmPassowrd;
}
private String userID;
public String getUser() {
	return user;
}
public void setUser(String user) {
	this.user = user;
}
public String getPass1() {
	return pass1;
}
public void setPass1(String pass1) {
	this.pass1 = pass1;
}

public String getUserID() {
	return userID;
}
public void setUserID(String userID) {
	this.userID = userID;
}

}
