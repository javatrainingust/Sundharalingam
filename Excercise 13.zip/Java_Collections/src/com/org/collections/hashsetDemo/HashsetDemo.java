
/***
 * Classname:HashsetDemo
 * 
 * Description:To achive Hashset
 *
 * Date:05.10.2020
 * 
***/	
package com.org.collections.hashsetDemo;

import java.util.HashSet;
import java.util.Set;
/***
 * HashsetDemo class used To achive Hashset
***/	
public class HashsetDemo {
public static void main(String[] args) {
Boolean b[]=new Boolean[3];
Set s=new HashSet();
String s1="test";
String s2="work";
String s3="test";

b[0]=s.add(s1);
b[1]=s.add(s2);
b[2]=s.add(s3);
for(Boolean bb:b) {
	System.out.println("Value for Boolean Array:"+bb);
}
for (Object o: s) {
	System.out.println("Value for set:"+o);
}
}
}
