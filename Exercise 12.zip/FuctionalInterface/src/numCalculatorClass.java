/***
 * numCalculator interface's class
 * 
 *
 *
 * Date:01.10.2020
 * 
**/	
public class numCalculatorClass {
public static void main(String[] args) {
	numCalculator num=(a,b)->a+b;
	
	System.out.println("Result of Add number:"+num.getValue(5, 10));
}
}
