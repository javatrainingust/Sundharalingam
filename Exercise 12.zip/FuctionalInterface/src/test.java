/***
 * Test interface
 * 
 *
 *
 * Date:01.10.2020
 * 
**/	
public interface Test {
public void test();
}
