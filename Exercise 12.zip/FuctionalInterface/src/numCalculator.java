/***
 * numCalculator interface
 * 
 *
 *
 * Date:01.10.2020
 * 
**/	
public interface numCalculator {

	public int getValue(int a, int b);
}
