/***
 * CheckValue interfac's  class
 * 
 *
 *
 * Date:01.10.2020
 * 
**/	
public class checkInClass {
	
	
	public static void main(String[] args) {
		CheckValue num=(n)  -> true;
			System.out.println("5 is num"+num.check(5));
	}
	

}
