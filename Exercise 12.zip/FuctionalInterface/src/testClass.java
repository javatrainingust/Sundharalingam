/***
 * testClass interface's class
 * 
 *
 *
 * Date:01.10.2020
 * 
**/	
public class testClass {
public static void main(String[] args) {
	Test t=()->{ System.out.println("Test Method calling");};
	t.test();
}
}
