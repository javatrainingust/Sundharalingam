/***
 * Interface:CheckValue
 * 
 *To check number or not
 *
 * Date:01.10.2020
 * 
**/	
public interface CheckValue {
	public boolean check(int n);
}
