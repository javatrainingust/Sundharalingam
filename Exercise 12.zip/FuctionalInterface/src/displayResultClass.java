/***
 * displayResult interface's  class
 * 
 *
 *
 * Date:01.10.2020
 * 
**/	
public class displayResultClass {

	public static void main(String[] args) {
		displayResult dis=(s)->{System.out.println("Display Result"+s);};
		
		dis.display("Sundharalingam");
		
	}
}
