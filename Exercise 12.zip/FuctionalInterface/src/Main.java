
public class Main {

	public static void main(String[] args) {
	
		//check value interface
		CheckValue num=(n)  -> { 
				System.out.println("CheckIn interface");
				System.out.println("******************");
				return (n==5);
			};
				System.out.println(num.check(5));
				System.out.println("--------------------------");
				
				//Display Result Interface
				System.out.println("Display Result interface");
				System.out.println("************************");
				displayResult dis=(s)->{System.out.println("Display Result:"+s);};
				
				dis.display("Sundharalingam");
				System.out.println("--------------------------");
				//number calculator
				System.out.println("Number Calculator Interface");
				System.out.println("***************************");
				numCalculator numb=(a,b)->a+b;
				
				System.out.println("Result of Add number:"+numb.getValue(5, 10));
				System.out.println("--------------------------");
				System.out.println("Number Calculator");
				System.out.println("******************");
				Test t=()->{ System.out.println("Test Method calling");};
				t.test();
				System.out.println("--------------------------");
	}
}
