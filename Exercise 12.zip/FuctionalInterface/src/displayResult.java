
public interface displayResult {

	public void display(String s);
}
