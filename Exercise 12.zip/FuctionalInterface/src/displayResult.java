/***
 * displayResult interface
 * 
 *
 *
 * Date:01.10.2020
 * 
**/	
public interface displayResult {

	public void display(String s);
}
