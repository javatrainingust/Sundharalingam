/***
 * Class:Organizers
 * Description: This is a spring example about organizers demo
 * Date:12-10-2020
*/
package com.org.sns.spring;
/***
 *Organizers is a spring example about organizers
*/
public class Organizers {
	/***
	 * Organizer constructor
	 * */
public Organizers() {
	System.out.println("Contructor of Organizer");
}
/***sayGreetings mryhod calling*/
public void sayGreetings() {
	System.out.println("Welcome to the talent competion");
}
}
