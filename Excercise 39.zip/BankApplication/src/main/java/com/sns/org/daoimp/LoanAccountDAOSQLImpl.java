/***
 * Classname: LoanAccountDAOSQLImpl
 * 
 * Description:this class used to achive SQL dao for LoanAccount
 *
 * Date:23.10.2020
 * 
*/package com.sns.org.daoimp;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sns.org.model.LoanAccount;
import com.sns.org.model.SBAccount;
/***
 * Classname: LoanAccountDAOSQLImpl class used to achive SQL dao for LoanAccount
*/
@Repository
public class LoanAccountDAOSQLImpl implements LoanAccountDAO {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;
		/***
		 * to set data source*/
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
		/***
		 * get all accounts*/
	public List<LoanAccount> getAllAccounts() {
		String SQL = "select * from loanaccount";
	      List <LoanAccount> accounts= jdbcTemplateObject.query(SQL, new LoanAccountMapper());
		
		return accounts;
	}
/**
 * get account by accountnum
 * **/
	public LoanAccount getAccountByAccountNumber(int accountNum) {
		String sql = "SELECT * FROM loanaccount WHERE accountNumber = ?";
		 
		LoanAccount account = (LoanAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNum }, new LoanAccountMapper());
      
       return 	account;	
	}
/*
 * delete account
 * **/
	public void deleteAccount(int accountNum) {
		 String query="delete from loanaccount where accountNumber='"+accountNum+"' ";  
		 jdbcTemplateObject.update(query);  
	}
/***
 * add account
 * **/
	public boolean addAccount(LoanAccount la) {
		String sql = "INSERT INTO loanaccount " +
	            "(accountNumber, accountHoderName, emi,loanOutStanding,tenture) VALUES (?, ?, ?,?,?)";
	  
		jdbcTemplateObject.update(sql, new Object[] { la.getAccountNumber(),la.getAccountHoderName(),
				la.getEmi(), la.getLoanOutStanding(),la.getTenture() 
	        });   
	  

		return true;
	}
	/***
	 * add account
	 * **/
	public void updateAccount(LoanAccount fda) {
		String query="update loanaccount set  accountHoderName='"+fda.getAccountHoderName()+"',loanOutStanding='"+fda.getLoanOutStanding()+"' where id='"+fda.getAccountNumber()+"' ";  
	    jdbcTemplateObject.update(query); 
	}

}
