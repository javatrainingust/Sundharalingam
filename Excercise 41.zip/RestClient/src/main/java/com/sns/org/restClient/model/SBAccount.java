/**
 * Class: SBAccount
 * Discription: its used to implement rest in java for SBAccount
 * date:28.10.20
 * */
package com.sns.org.restClient.model;
/**
 *SBAccount used to implement rest in java for SBAccount
 ** */
public class SBAccount {
	private float balance=5000;
	private int year=1;
	private float ratio=5;
	private int accountNumber;
	private String accountHoderName;
	/**
	 * construcors*
	 * */
	public SBAccount(){}
	/***
	 * paramerteized constructor
	 * **/
	public SBAccount(float balance,int year,float ratio,int accountNumber,String accountHoderName){
		this.balance=balance;
		this.year=year;
		this.ratio=ratio;
		this.accountNumber=accountNumber;
		this.accountHoderName=accountHoderName;
	}
	
	/***
	 * Getters and setters
	 * 
	 * ***/
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public float getRatio() {
		return ratio;
	}
	public void setRatio(float ratio) {
		this.ratio = ratio;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHoderName() {
		return accountHoderName;
	}
	public void setAccountHoderName(String accountHoderName) {
		this.accountHoderName = accountHoderName;
	}
}
