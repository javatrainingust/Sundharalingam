/**
 * Class:RestClientApplication
 * Discription: its used to implement rest in java
 * date:28.10.20
 * */

package com.sns.org.restClient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.sns.org.restClient.model.SBAccount;

@SpringBootApplication
/**
 *RestClientApplication used to implement rest in java
 ****/
public class RestClientApplication {
/***
 * main method
 * */
	public static void main(String[] args) {
		SpringApplication.run(RestClientApplication.class, args);
		//postResource();
		//putResource();
		//getResource();
		deleteResource();
		
		//getAllResources();
		
	}
	/**
	 * get specified by account
	 * */
public static void  getResource() {
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8181/bank/accounts/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 1519);
	     
	    
	    SBAccount sb=restTemplate.getForObject(uri, SBAccount.class, params);
	    
	    System.out.println("SB AccountHolder name: "+sb.getAccountHoderName());
	    System.out.println("SB Account Number: "+sb.getAccountNumber());
	    System.out.println("SB Account Balance: "+sb.getBalance());
		
		
	}
	
	/**
	 * get All Accounts
	 * **/
	public static void getAllResources() {
		
		System.out.println("Inside getAllResources() method");
	
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8181/bank//accounts";
	    	     
	    	     
	    ResponseEntity<SBAccount[]> response  = restTemplate.getForEntity(uri, SBAccount[].class);
	    
	    SBAccount[] accounts = response.getBody();

	    
	    for(int i=0; i<accounts.length;i++) {
	    	
	    	SBAccount sb= (SBAccount)accounts[i];	    
	    System.out.println("SB AccountHolder name: "+sb.getAccountHoderName());
	    System.out.println("SB Account Number: "+sb.getAccountNumber());
	    System.out.println("SB Account Balance: "+sb.getBalance());
	    
	    }
		
		
		
	}
	/**
	 * 
	 * create post request
	 * **/
	public static void postResource() {
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8181/bank/accounts";
		
		SBAccount sba=new SBAccount(50000,2, 8, 1519, "Athvi");
	
		
		SBAccount result = restTemplate.postForObject( uri, sba, SBAccount.class);
		
		
	}
	
	/**
	 * update request
	 * */
	public static void putResource() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8181/bank/accounts/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 1519);
	    SBAccount updateAccount=new SBAccount(50000,2, 8, 1519, "Athvigan"); 
	    
	     restTemplate.put(uri, updateAccount, params);
		
		
		
		
	}
	
	/**
	 * delete request
	 * ***/
	public static void deleteResource() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8181/bank/accounts/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 1519);
	     
	     restTemplate.delete(uri, params);
	}

}
