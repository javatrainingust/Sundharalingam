package com.sns.org.banking.BankingApplication;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sns.org.daoimp.SBAccountDAO;
import com.sns.org.model.SBAccount;
import com.sns.org.servics.SBAccountService;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class BankingApplicationTests {

	@Mock
	private SBAccountDAO sbAccounctDAMOMock;

	@InjectMocks
	private SBAccountService service;

	@Test
	public void testGetAllAccountsByBalance() {
		SBAccount sb1 = new SBAccount();
		sb1.setBalance(5000);
		SBAccount sb2 = new SBAccount();
		sb2.setBalance(6000);
		SBAccount sb3 = new SBAccount();
		sb3.setBalance(7000);
		SBAccount sb4 = new SBAccount();
		sb4.setBalance(8000);

		List<SBAccount> accounts = new ArrayList();
		accounts.add(sb1);
		accounts.add(sb2);
		accounts.add(sb3);
		accounts.add(sb4);
		when(sbAccounctDAMOMock.getAllAccounts()).thenReturn(accounts);

		assertEquals(2, service.getAccountsBasedOnBalance(6500).size());

	}
}