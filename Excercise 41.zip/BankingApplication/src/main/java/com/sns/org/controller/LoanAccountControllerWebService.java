/***
 * Class: LoanAccountControllerWebService
 * 
 * Description:this class used to implement  controller for LoanAccount
 *
 * Date:22.10.2020
 * 
*/
package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sns.org.servics.LoanAccountService;
import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;
import com.sns.org.model.LoanAccount;
import com.sns.org.model.SBAccount;

/***
 * LoanAccountControllerWebService class used to implement controller for LoanAccount
 */
@RestController
public class LoanAccountControllerWebService {
	@Autowired
	private LoanAccountService service;

	/** current account adding */
	@PostMapping("/loanaccounts")
	public LoanAccount addAccount(@RequestBody LoanAccount la) {

		service.addloanAccount(la);

		return la;
	}

	/**
	 * Get All Accounts
	 */
	@GetMapping("/loanaccounts")
	public List getLoanAccount() {

		System.out.println("Inside controller getAllAccounts");
		List<LoanAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);

		return accountList;

	}

	/**
	 * Get All Accounts sortLoanAccountByName
	 */
	@RequestMapping("/sortLoanAccountByName")

	public String getAllLoanAccountByName(Model model) {

		System.out.println("Inside controller getAllAccounts");
		List<LoanAccount> accountList = service.getAllAccountsSortedByNames();
		System.out.println(accountList);
		model.addAttribute("loanAccount", accountList);

		return "loanAccount";

	}

	/**
	 * Get All Accounts sortLoanAccountByName
	 */
	@RequestMapping("/sortLoanAccountBybalance")

	public String getAllLoanAccountBybalance(Model model) {

		System.out.println("Inside controller getAllAccounts");
		List<LoanAccount> accountList = service.getAllFDAccountsSortedByEMI();
		System.out.println(accountList);
		model.addAttribute("loanAccount", accountList);

		return "loanAccount";

	}

	/**
	 * update Account
	 */
	@PutMapping("/loanaccounts/{id}")
	public LoanAccount updateAccounts(@PathVariable int id, @RequestBody LoanAccount la) {

		service.updateloanAccount(la);

		return la;

	}

	/**
	 * Get specified account details
	 */
	@GetMapping("/loanaccounts/{id}")
	public LoanAccount getAccounts(@PathVariable int id) {

		LoanAccount la = service.getLoanAccountByAccountNumber(id);

		return la;

	}

	/**
	 * Delete specified account details
	 */
	@DeleteMapping("/loanaccounts/{id}")
	public void deleteEmployee(@PathVariable int id) {

		service.deleteLoanAccount(id);

	}
}
