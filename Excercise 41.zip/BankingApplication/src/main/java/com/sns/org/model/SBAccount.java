/****
 * Classname:SBAccount
 * 
 * Description:This is a child class of Account Class. This class used to handle a Saving Account  
 *
 * Date:30.09.2020
 * 
***/	
package com.sns.org.model;

import com.sns.org.exception.InsufficentBalanceException;
import com.sns.org.util.InterestCalculator;
/***This class used to handle a Saving Account  ***/	
public class SBAccount extends Account implements Comparable<SBAccount> {
	

private int year=1;
private float ratio=5;
private int accountNumber;
private String accountHoderName;
private float balance;
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}
public SBAccount(int accountNumber, String accountHoderName, float balance) {
	this.accountHoderName=accountHoderName;
	this.balance=balance;
	this.accountNumber=accountNumber;
}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public String getAccountHoderName() {
	return accountHoderName;
}
public void setAccountHoderName(String accountHoderName) {
	this.accountHoderName = accountHoderName;
}

private InterestCalculator interestcalculator=new InterestCalculator(); 

/***parent constructor with no arguments***/	
public SBAccount() {
		System.out.println("SBAccount Class with no arg");
	}
/***constructor with arguments***/	
	public SBAccount(float balance, int year) {
		this();
		//super();
		System.out.println("SBA Account Class With arg\n");
	}
	/***To Get Year***/	
	public int getYear() {
		System.out.println("Year:"+year);
		return year;
	}
	/***To Set Year***/	
	public void setYear(int year) {
	
		this.year = year;
	}
	/***To Get radio***/	
	public float getRatio() {
		//System.out.println("Ratio of Interest:"+ratio+"%");
		return ratio;
	}
	/***To Set radio***/	
	public void setRatio(double d) {
		this.ratio = (float) d;
	}
	/***To Get Balance***/	
	

	/***To Set Balance***/	
	

	/**** withdraw money from balance****/	
	public void withdrawMoney(int amount) throws InsufficentBalanceException {
		System.out.println("Withdraw Amount:"+amount);
		if(balance>amount) {
			balance=balance-amount;
			System.out.println("Balance:"+balance);
		}
		else {
			
			throw new InsufficentBalanceException(amount);
		//System.out.println("You don't have enaugh money");
		}
	}

	/****overriding method for calculate interest***/	
	public void interestCalculator() {
	float interest=interestcalculator.intrestCalculate(balance, year, ratio);;
	System.out.println("Saving Account Interest:"+interest);
	System.out.println("Total:"+(interest+balance));
}
	/*
	 * 
	 * override compareto method
	 */
	
	public int compareTo(SBAccount o) {
		// TODO Auto-generated method stub
		return this.accountHoderName.compareTo(o.getAccountHoderName());
	}


}
