/***
 * Class: SBAccountControllerWebService
 * 
 * Description:this class used to implement  controller for SBAccount
 *
 * Date:22.10.2020
 * 
*/
package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sns.org.model.LoanAccount;
import com.sns.org.model.SBAccount;

import com.sns.org.servics.SBAccountService;

/***
 * SBAccountControllerWebService class used to implement controller for
 * SBAccount
 */
@RestController
public class SBAccountControllerWebService {
	@Autowired
	private SBAccountService service;

	/** current account adding */
	@PostMapping("/accounts")
	public SBAccount addAccount(@RequestBody SBAccount sb) {

		service.addSBAccount(sb);

		return sb;

	}

	/**
	 * update Account
	 */
	@PutMapping("/accounts/{id}")
	public SBAccount updateAccounts(@PathVariable int id, @RequestBody SBAccount sb) {

		SBAccount oldsb = service.getSBAccountByAccountNumber(id);
		if (oldsb != null) {
			service.updateSBAccount(sb);
		}
		return sb;

	}

	/**
	 * Get All Accounts
	 */

	@GetMapping("/accounts")
	public List getAllSBAccounts() {

		System.out.println("Inside controller getAllAccounts");
		List<SBAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);
		// model.addAttribute("sbAccount", accountList);

		return accountList;

	}

	/**
	 * Get All Accounts sortSBAccountByName
	 */

	@RequestMapping("/sortSBAccountByName")

	public String getAllsortSBAccountByName(Model model) {

		System.out.println("Inside controller getAllAccounts");
		List<SBAccount> accountList = service.getAllAccountsSortedByNames();
		System.out.println(accountList);
		model.addAttribute("sbAccount", accountList);

		return "sbAccount";

	}

	/**
	 * Get All Accounts
	 */

	@RequestMapping("/sortSBAccountBybalance")

	public String getAllsortSBAccountBybalance(Model model) {

		System.out.println("Inside controller getAllAccounts");
		List<SBAccount> accountList = service.getAllFDAccountsSortedByFDAmount();
		System.out.println(accountList);
		model.addAttribute("sbAccount", accountList);

		return "sbAccount";

	}

	/**
	 * Get All Accounts by balance
	 */

	@GetMapping("/accounts-balance/{basic}")
	public List<SBAccount> getAccountBasedOnSalary(@PathVariable float basic) {

		List<SBAccount> accountList = service.getAccountsBasedOnBalance(basic);

		return accountList;

	}

	/**
	 * Get specified account details
	 */
	@GetMapping("/accounts/{id}")
	public SBAccount getAccounts(@PathVariable int id) {

		SBAccount sb = service.getSBAccountByAccountNumber(id);

		return sb;

	}

	/**
	 * Delete specified account details
	 */
	@DeleteMapping("/accounts/{id}")
	public void deleteEmployee(@PathVariable int id) {

		service.deleteSBAccount(id);

	}
}
