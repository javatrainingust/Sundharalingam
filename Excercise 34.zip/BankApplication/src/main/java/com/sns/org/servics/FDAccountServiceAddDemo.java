/***
 * class: FDAccountServiceAddDemo
 * 
 * Description:this class used to add and update FDAccount 
 *
 * Date:08.10.2020
 * 
*/package com.sns.org.servics;

import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;

public class FDAccountServiceAddDemo {

	/**
	 * main method
	 * */
		public static void main(String[] args) {
		FDAccountService service=new FDAccountService();
		
		service.addfdAccount(new FDAccount(1510, "Sundhara", 50000, 2, 8));
		service.addfdAccount(new FDAccount(1511, "Viji", 80000, 2, 8));
		service.addfdAccount(new FDAccount(1512, "Aruthra", 90000, 2, 8));
		service.addfdAccount(new FDAccount(1513, "Athvi", 20000, 2, 8));
		 
		System.out.println("Printing all accounts");	
		service.getAllAccounts();
		System.out.println("---------------------------------------------");	
		service.addfdAccount(new FDAccount(1510, "Sundharalingam", 80000, 2, 8));
		System.out.println("Printing all updated accounts");	
		service.getAllAccounts();
		
		}


}
