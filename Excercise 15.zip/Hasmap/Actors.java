

/***
 * Classname:Actors
 * 
 * Description:To achive Hasmap
 *
 * Date:05.10.2020
 * 
***/	
package com.org.collections.Hasmap;

import java.util.HashMap;
import java.util.Map;

public class Actors {
public static void main(String[] args) {
	Map Actors = new HashMap<String, Integer>();
	
	Actors.put("Vijay", "Sachine");
	Actors.put("Ajith", "Billa");
	Actors.put("STR", "Vallavan");
	
	
	
	
        System.out.println("Ajith Kumar's Movie: " +Actors.get("Ajith"));
   
}
}
