
/***
 * Classname:CatDemo 
 * 
 * Description:To achive Hasmap
 *
 * Date:05.10.2020
 * 
***/	
package com.org.collections.Hasmap;

import java.util.HashMap;
import java.util.Map;

import com.org.collections.hashsetDemo.Cats;

public class CatDemo {

	public static void main(String[] args) {
		
		Cats c1=new Cats("Rosy", 2);
		Cats c2=new Cats("Pinky", 3);
		Cats c3=new Cats("Jimmy", 5);	
		Map catOwners = new HashMap<CatDemo,String>();
		
		catOwners.put(c1, "Sundhar");
		catOwners.put(c2, "Viji");
		catOwners.put(c3, "Aruthra");	
		
		System.out.println("Owner of Rosy cat : " +catOwners.get(new Cats("Rosy", 2)));
		
		System.out.println("Owner of Pinky cat : " +catOwners.get(new Cats("Pinky", 3)));
		
		System.out.println("Owner of Jimmy cat : " +catOwners.get(new Cats("Jimmy", 5) ));
		// TODO Auto-generated method stub

	}

}
