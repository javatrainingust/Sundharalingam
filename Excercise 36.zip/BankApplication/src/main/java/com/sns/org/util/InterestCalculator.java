/***
 * Interface Name:InterestCalculator
 * 
 * Description:This class used to define a interest calculate 
 *
 * Date:30.09.2020
 * 
**/	
package com.sns.org.util;
/**This class used to define a interest calculate **/	
public class InterestCalculator implements ICalculator {
Float si, p,r;
int n;
/**intrestCalculate with p , n , r in parameter **/	
	public float intrestCalculate(float p, int n, float r) {
		si=(float) ((p*n*r)/100);
		System.out.println("Fixed Deposite");
		System.out.println("****************************");
		System.out.println("Princple:"+p+"\t Tenure:"+n+"\t Ratio:"+r+"%");
		System.out.println("Interest of FD:"+si);
		return si;
	}
/**intrestCalculate with p , n  in parameter **/		
public float intrestCalculate(double p,int n) {
	r=(float) 5.0;
	System.out.println("Saving Account");
	System.out.println("****************************");
	si=(float) ((p*n*r)/100);
	System.out.println("Princple:"+p+"\t Tenure:"+n+"\t Ratio:"+r+"%");
	System.out.println("Interest of Saving Account:"+si);
	return si;
	}
}
