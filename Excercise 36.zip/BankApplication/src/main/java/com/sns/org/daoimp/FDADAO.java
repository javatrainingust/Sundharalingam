/***
 * interface: FDADAO
 * 
 * Description:this interface used to implement  dao for FDA
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import java.util.List;

import com.sns.org.model.FDAccount;

/***
 * 
 * This interface used to implement dao for FDA
 */
public interface FDADAO {
	/***
	 * 
	 * 
	 * method declaration for FDADAO interface
	 * 
	 */
	public List<FDAccount> getAllAccounts();

	public FDAccount getAccountByAccountNumber(int accountNum);

	public void deleteAccount(int accountNum);

	public boolean addAccount(FDAccount fda);

	public void updateAccount(FDAccount fda);

}
