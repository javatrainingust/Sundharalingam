/***
 * class: SBAccountDeleteDemo
 * 
 * Description:this class used to delete and print for SBAccount
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.servics;
/***
 *SBAccountDeleteDemo class used to delete and print for SBAccount
*/
public class SBAccountDeleteDemo {
//main method
	public static void main(String[] args) {
		
		
		SBAccountService service  =  new SBAccountService();

System.out.println("Printing all Accounts");
		
		service.getAllAccounts();
		
		
		System.out.println("----------------------------------");
		
		service.deleteSBAccount(1510);
		

System.out.println("Printing a specific Account");
		
		service.getAllAccounts();
		
	}
	

}

