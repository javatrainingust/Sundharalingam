/***
 * class: CurrentAccountDeleteDemo
 * 
 * Description:this class used to delete and print for CurrentAccount
 *
 * Date:06.10.2020
 * 
*/package com.sns.org.servics;

/***
 CurrentAccountDeleteDemo class used to delete and print for CurrentAccount
 
*/
public class CurrentAccountDeleteDemo {
	public static void main(String[] args) {
		
		
		CurrentAccountService service  =  new CurrentAccountService();
		
		
		System.out.println("Printing all employees");
		
		service.getAllAccounts();
		
		
		System.out.println("----------------------------------");
		
		service.deleteFDAccount(1510);
		
		System.out.println("After deletion");
		
		service.getAllAccounts();
		
	}
	
}
