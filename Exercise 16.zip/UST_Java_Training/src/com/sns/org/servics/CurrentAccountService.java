/***
 * class: CurrentAccountService
 * 
 * Description:this class used to implement CurrentAccountService
 *
 * Date:06.10.2020
 * 
*/package com.sns.org.servics;

import java.util.Iterator;
import java.util.List;

import com.sns.org.daoimp.CurrentAccountImp;
import com.sns.org.daoimp.FDADAOImp;
import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;
import com.sns.org.repository.CurrentAccountDAO;
import com.sns.org.repository.FDADAO;

public class CurrentAccountService {
	CurrentAccountDAO daoImpl;
	 public CurrentAccountService() {
		daoImpl = new CurrentAccountImp();
	}
	 
	 public List<CurrentAccountDAO> getAllAccounts() {
List l=null;
		List CurrentAccountList = daoImpl.getAllAccounts();

		//FDAccount FDAccount = null;
		Iterator<CurrentAccount> iterator = CurrentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = iterator.next();
System.out.println("Account Holder Name:"+ca.getAccountHoderName());
System.out.println("Account Number:"+ca.getAccountNumber());
System.out.println("OverDraft Limit:"+ca.getOverdraftLimit());
System.out.println("Balance:"+ca.getBalance());
			System.out.println("************************************************");

			}
			
			return l;
		}
		
		
		
		
		
	public CurrentAccount getFDAccountByAccountNumber(int getAccountNumber){
		CurrentAccount ca=daoImpl.getAccountByAccountNumber(getAccountNumber);

		System.out.println("Account Holder Name:"+ca.getAccountHoderName());
		System.out.println("Account Number:"+ca.getAccountNumber());
		System.out.println("OverDraft Limit:"+ca.getOverdraftLimit());
		System.out.println("Balance:"+ca.getBalance());
		return ca;
		
		
		
	}
		
		
	public void deleteFDAccount(int accountNumber) {
		
		
		
		daoImpl.deleteAccount(accountNumber);;
		
		
		
		
		
	}	
	

}
