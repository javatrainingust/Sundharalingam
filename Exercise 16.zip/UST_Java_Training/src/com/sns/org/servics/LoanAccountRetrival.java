/***
 * class: LoanAccountRetrival
 * 
 * Description:this class used to print all and print specific accounts for LoanAccount
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.servics;

public class LoanAccountRetrival {

public static void main(String[] args) {
		
		LoanAccountService service  =  new LoanAccountService();
		
		System.out.println("Printing all Accounts");
		
		service.getAllAccounts();
		
		System.out.println("--------------------------------");
		
		System.out.println("Printing a specific Account");
		
		service.getLoanAccountByAccountNumber(1510);
	}
}
