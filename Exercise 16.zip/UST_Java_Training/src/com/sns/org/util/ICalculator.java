/***
 * Interface Name:ICalculator
 * 
 * Description:This interface used to define a interest calculate 
 *
 * Date:30.09.2020
 * 
**/	
package com.sns.org.util;
/**This interface used to define a interest calculate **/	
public interface ICalculator {

/**these methods used to calculate Interest, Apastract Method**/	
	public float intrestCalculate(float p, int n, float r) ;
	public float intrestCalculate(double p,int n);
}
