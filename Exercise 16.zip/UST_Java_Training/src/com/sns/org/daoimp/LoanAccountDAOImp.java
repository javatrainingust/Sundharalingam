/***
 * Classname: LoanAccountDAOImp
 * 
 * Description:this class used to achive dao for LoanAccountDAOImp
 *
 * Date:06.10.2020
 * 
*/package com.sns.org.daoimp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sns.org.model.FDAccount;
import com.sns.org.model.LoanAccount;
/***
 * LoanAccountDAOImp class used to achive dao for LoanAccountDAOImp and it implements LoanAccountDAO
*/
public class LoanAccountDAOImp implements LoanAccountDAO{

List loanAccountList;
	/*LoanAccountDAOImp constructor*/
	public LoanAccountDAOImp() {
loanAccountList = new ArrayList<LoanAccount>();
		
LoanAccount la1 = new LoanAccount(1510, "Sundhara", 5000, 500, 2);
LoanAccount la2 = new LoanAccount(1511, "Viji", 5679, 700, 1);
LoanAccount la3 = new LoanAccount(1512, "Aruthra", 8976, 567, 3);
LoanAccount la4 = new LoanAccount(1513, "Athvi", 6700, 590, 4);
loanAccountList.add(la1);
loanAccountList.add(la2);
loanAccountList.add(la3);
loanAccountList.add(la4);	// TODO Auto-generated constructor stub
	}
	/** 
	 * Display all the accounts*
	 **/
	
	@Override
	public List<LoanAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		return loanAccountList;
	}
	/** 
	 * Display accounts by accountNum*
	 **/
	
	@Override
	public LoanAccount getAccountByAccountNumber(int accountNum) {
		LoanAccount LoanAccount =null;
		
		Iterator<LoanAccount>   iterator = loanAccountList.iterator();
		
		while(iterator.hasNext()){
			
			LoanAccount ld = iterator.next();
			
			if(ld.getAccountNumber()==accountNum){
				LoanAccount=ld;	
			}	
		}	
		
		// TODO Auto-generated method stub
		return LoanAccount;
	}
	/*Delete the account*/ 
	@Override
	public void deleteAccount(int accountNum) {
		for(int i=0; i< loanAccountList.size(); i++){		
			LoanAccount fd =(LoanAccount)loanAccountList.get(i);
			if(fd.getAccountNumber()==accountNum){
				loanAccountList.remove(i);
			}		
			}	
	}

	@Override
	public boolean addAccount(LoanAccount fda) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void updateAccount(LoanAccount fda) {
		// TODO Auto-generated method stub
		
	}

	
}
