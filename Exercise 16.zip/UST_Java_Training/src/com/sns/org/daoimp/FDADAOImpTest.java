/***
 * Classname: FDADAOImpTest
 * 
 * Description:this class used to achive dao for FDADAOImpTest
 *
 * Date:06.10.2020
 * 
*/package com.sns.org.daoimp;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.sns.org.model.FDAccount;

/***FDADAOImpTest  class used to achive dao for FDADAOImp*/
class FDADAOImpTest {
	List fdAccountListTest;

/***constructor FDADAOImpTest  class */
	public FDADAOImpTest() {
		fdAccountListTest = new ArrayList<FDAccount>();
		FDAccount account1 = new FDAccount(1510,"Sundhara", 50000, 2, 8) ;
		FDAccount account2 = new FDAccount(1511,"Viji", 80000,2, 8) ;
		FDAccount account3 = new FDAccount(1512,"Aruthra", 90000,2, 8) ;
		FDAccount account4 = new FDAccount(1513,"Athvi", 20000,2, 8) ;
	
		fdAccountListTest.add(account1);
		fdAccountListTest.add(account2);
		fdAccountListTest.add(account3);
		fdAccountListTest.add(account4);
	}
	/** 
	 * Display all the accounts*
	 **/
	
	@Test
	void testGetAllAccounts() {
		List<FDAccount> actualList = new ArrayList<FDAccount>();
		FDADAOImp daoImp = new FDADAOImp();
		actualList = daoImp.getAllAccounts();
		assertEquals(actualList.size(), fdAccountListTest.size());
	}
	/** 
	 * Display accounts by accountNum*
	 **/
	@Test
	void testGetAccountByAccountNumber() {
		FDAccount actual = (FDAccount)fdAccountListTest.get(0);
		FDADAOImp daoImp = new FDADAOImp();
		FDAccount expected = daoImp.getAccountByAccountNumber(1510);
		assertEquals(actual.getAccountHoderName(), expected.getAccountHoderName());
	}

	/*Delete the account*/ 
	@Test
	void testDeleteAccount() {
		List<FDAccount> actualList = new ArrayList<FDAccount>();
		FDADAOImp daoImp = new FDADAOImp();
		daoImp.deleteAccount(1513);
		actualList = daoImp.getAllAccounts();
		assertEquals(actualList.size(), fdAccountListTest.size()-1);
	}

}
