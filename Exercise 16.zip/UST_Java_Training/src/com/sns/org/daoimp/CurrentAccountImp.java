/***
 * Classname:CurrentAccountImp
 * 
 * Description:this class used to achive dao for CurrentAccount
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;
import com.sns.org.repository.CurrentAccountDAO;

public class CurrentAccountImp implements CurrentAccountDAO {
List currentAccountList;
	
	public CurrentAccountImp() {
		currentAccountList = new ArrayList<CurrentAccount>();
		
		CurrentAccount account1 = new CurrentAccount(1510, "sundhara", 200000, 786765);
		CurrentAccount account2 = new CurrentAccount(1511,"Viji", 80000,87876) ;
		CurrentAccount account3 = new CurrentAccount(1512, "Aruthra", 980000, 186765);
		CurrentAccount account4 = new CurrentAccount(1513, "Athvi", 540000, 56765);
		currentAccountList.add(account1);
		currentAccountList.add(account2);
		currentAccountList.add(account3);
		currentAccountList.add(account4);
			// TODO Auto-generated constructor stub
	}
	@Override
	public List<CurrentAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		return currentAccountList;
	}

	@Override
	public CurrentAccount getAccountByAccountNumber(int accountNum) {
		CurrentAccount CurrentAccount =null;
		
		Iterator<CurrentAccount>   iterator = currentAccountList.iterator();
		
		while(iterator.hasNext()){
			
			CurrentAccount fd = iterator.next();
			
			if(fd.getAccountNumber()==accountNum){
				CurrentAccount=fd;	
			}	
		}	
		
		// TODO Auto-generated method stub
		return CurrentAccount;
		}

	@Override
	public void deleteAccount(int accountNum) {
		for(int i=0; i< currentAccountList.size(); i++){		
			CurrentAccount fd =(CurrentAccount)currentAccountList.get(i);
			if(fd.getAccountNumber()==accountNum){
				currentAccountList.remove(i);
			}		
			}		
	}

	@Override
	public boolean addAccount(CurrentAccount fda) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void updateAccount(CurrentAccount fda) {
		// TODO Auto-generated method stub
		
	}

}
