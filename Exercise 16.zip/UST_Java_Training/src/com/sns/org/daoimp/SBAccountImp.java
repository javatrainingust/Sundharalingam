/***
 * Classname: SBAccountImp
 * 
 * Description:this class used to achive dao for SBAccountImp
 *
 * Date:06.10.2020
 * 
*/package com.sns.org.daoimp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sns.org.model.FDAccount;
import com.sns.org.model.SBAccount;
import com.sns.org.repository.SBAccountDAO;


public class SBAccountImp implements SBAccountDAO {
	List SBAccountList;
	 public SBAccountImp() {
		SBAccountList = new ArrayList<SBAccount>();
		SBAccount sba1=new SBAccount(1510, "Sundhara", 50000);
		SBAccount sba2=new SBAccount(1511, "Aruthra", 90000);
		SBAccount sba3=new SBAccount(1512, "Viji", 99000);
		SBAccount sba4=new SBAccount(1513, "athvi", 66000);
		SBAccountList.add(sba1);
		SBAccountList.add(sba2);
		SBAccountList.add(sba3);
		SBAccountList.add(sba4);
		 
	 }
	 @Override
		public List<SBAccount> getAllAccounts() {
			// TODO Auto-generated method stub
			return SBAccountList;
		}
		
	 
	 @Override
	public SBAccount getAccountByAccountNumber(int accountNum) {
		 SBAccount SBAccount =null;
			
			Iterator<SBAccount>   iterator = SBAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SBAccount sb = iterator.next();
				
				if(sb.getAccountNumber()==accountNum){
					SBAccount=sb;	
				}	
			}	
			
			// TODO Auto-generated method stub
			return SBAccount;
	}
	@Override
	public void deleteAccount(int accountNum) {
		for(int i=0; i< SBAccountList.size(); i++){		
			FDAccount fd =(FDAccount)SBAccountList.get(i);
			if(fd.getAccountNumber()==accountNum){
				SBAccountList.remove(i);
			}		
			}	
	}
	@Override
	public boolean addAccount(SBAccount fda) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void updateAccount(SBAccount fda) {
		// TODO Auto-generated method stub
		
	}
	

}
