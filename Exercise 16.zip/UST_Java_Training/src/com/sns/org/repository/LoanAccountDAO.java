/***
 * interface: LoanAccountDAO
 * 
 * Description:this interface used to implement  dao for LoanAccount
 *
 * Date:06.10.2020
 * 
*/package com.sns.org.repository;

import java.util.List;

import com.sns.org.model.FDAccount;
import com.sns.org.model.LoanAccount;

public interface LoanAccountDAO {

public List<LoanAccount> getAllAccounts();
	
	public LoanAccount getAccountByAccountNumber(int accountNum);
	
	public void deleteAccount(int accountNum);
	
	public boolean addAccount(LoanAccount fda);
	
	public void updateAccount(LoanAccount fda);

}
