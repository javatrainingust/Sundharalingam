/***
 * interface: FDADAO
 * 
 * Description:this interface used to implement  dao for FDA
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.repository;

import java.util.List;

import com.sns.org.model.FDAccount;

public interface FDADAO {
public List<FDAccount> getAllAccounts();
	
	public FDAccount getAccountByAccountNumber(int accountNum);
	
	public void deleteAccount(int accountNum);
	
	public boolean addAccount(FDAccount fda);
	
	public void updateAccount(FDAccount fda);

}
