/***
 * interface: SBAccountDAO
 * 
 * Description:this interface used to implement  dao for SBAccount
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.repository;

import java.util.List;

import com.sns.org.model.FDAccount;
import com.sns.org.model.SBAccount;

public interface SBAccountDAO {

	public List<SBAccount> getAllAccounts();
	
	public SBAccount getAccountByAccountNumber(int accountNum);
	
	public void deleteAccount(int accountNum);
	
	public boolean addAccount(SBAccount fda);
	
	public void updateAccount(SBAccount fda);
}
