/***
 * Classname:Calculator
 * 
 * Description: calculate class handle and add and subtract method  
 *
 * Date:01.10.2020
 * 
**/	
package com.org.junit.util;
/* */
public class Calculator {
//add method is used to add two values
	public int add(int a, int b) {
		return a+b;
	}
	//sutract method is used to subract two values
	public int subtract(int a, int b) {
		return a-b;
	}
}
