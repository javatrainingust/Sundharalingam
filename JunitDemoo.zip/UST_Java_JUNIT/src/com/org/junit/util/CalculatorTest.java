/***
 * Classname:CalculatorTest
 * 
 * Description: Junit caling calculator method  
 *
 * Date:01.10.2020
 * 
**/	package com.org.junit.util;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
/**** Classname:CalculatorTest***/
class CalculatorTest {

	@Test
	void testAdd() {
		int ExpectedValue=7;
		int ActualValue=new Calculator().add(4, 3);
		assertEquals(ExpectedValue, ActualValue);
	}

	@Test
	void testSubtract() {
		int ExpectedValue=1;
		int ActualValue=new Calculator().subtract(4, 3);
		assertEquals(ExpectedValue,ActualValue);
	}

}
