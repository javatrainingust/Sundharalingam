/***
 * Classname:CurrentAccount
 * 
 * Description:/***sub class for account derived from account class . This class used to maintain a Current Account  
 *
 * Date:30.09.2020
 * 
**/	
package com.sns.org.model;
/***sub class for account derived from account class **/	
public class CurrentAccount extends Account{
	private int accountNumber;
	private String accountHoderName;
private int overDraftLimit;
private float balance;
public CurrentAccount(int accountNumber,String accountHoderName,int overDraftLimit, float balance) {
	this.accountNumber=accountNumber;
	this.accountHoderName=accountHoderName;
	this.overDraftLimit=overDraftLimit;
	this.balance=balance;
}



public float getBalance() {
	return balance;
}



public void setBalance(float balance) {
	this.balance = balance;
}



/***get the limit of over draft**/	
public int getOverdraftLimit() {
	//System.out.println("OverDraft Limit:"+overDraftLimit);
return overDraftLimit;
	}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public String getAccountHoderName() {
	return accountHoderName;
}
public void setAccountHoderName(String accountHoderName) {
	this.accountHoderName = accountHoderName;
}
/***set the limit of over draft**/	
public void setOverdraftLimit(int overDraftLimit) {
	this.overDraftLimit = overDraftLimit;
}
}
