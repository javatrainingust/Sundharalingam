/***
 * class: FDAccountRetrivalDemo
 * 
 * Description:this class used to print all and print specific accounts for FDAccount
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.servics;
/***
FDAccountRetrivalDemo class used to print all and print specific accounts for FDAccount
 * 
*/
public class FDAccountRetrivalDemo {
/*main method*/
	public static void main(String[] args) {
		
		FDAccountService service  =  new FDAccountService();
		
		System.out.println("Printing all employees");
		
		service.getAllAccounts();
		
		System.out.println("--------------------------------");
		
		System.out.println("Printing a specific employee");
		
		service.getFDAccountByAccountNumber(1510);
	}

}
