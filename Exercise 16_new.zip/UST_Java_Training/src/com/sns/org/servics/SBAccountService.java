/***
 * class: SBAccountService
 * 
 * Description:this class used to implement SBAccountServicet
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.servics;

import java.util.Iterator;
import java.util.List;

import com.sns.org.daoimp.FDADAO;
import com.sns.org.daoimp.FDADAOImp;
import com.sns.org.daoimp.SBAccountDAO;
import com.sns.org.daoimp.SBAccountImp;
import com.sns.org.model.FDAccount;
import com.sns.org.model.SBAccount;
/***
 SBAccountService class used to implement SBAccountServicet

*/
public class SBAccountService {
/*constructor*/
	SBAccountDAO daoImpl;
	 public SBAccountService() {
		// TODO Auto-generated constructor stub
		
		daoImpl = new SBAccountImp();
		
		
	}
		/** 
		 * Display all the accounts*
		 **/
		
	
	public List<SBAccountDAO> getAllAccounts() {
List l=null;
		List SBAccountList = daoImpl.getAllAccounts();

		
		Iterator<SBAccount> iterator = SBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account Id: " + sb.getAccountNumber());
			System.out.println("Account Holder Name: " + sb.getAccountHoderName());
			System.out.println("Balance: " + sb.getBalance());
			System.out.println("************************************************");

			}
			
			return l;
		}
		
		
		
	/** 
	 * Display accounts by accountNum*
	 **/
	
		
	public SBAccount getSBAccountByAccountNumber(int getAccountNumber){
		SBAccount sb=daoImpl.getAccountByAccountNumber(getAccountNumber);
		System.out.println("Account Number: "+sb.getAccountNumber());
		System.out.println("Account Holder Name: "+sb.getAccountHoderName());
		System.out.println("Balance: " + sb.getBalance());
		return sb;
		
		
		
	}
		
	/*Delete the account*/ 
	public void deleteSBAccount(int accountNumber) {
		
		
		
		daoImpl.deleteAccount(accountNumber);;
		
		
		
		
		
	}	
	

}
