/***
 * Classname: SBAccountImpTest
 * 
 * Description:this class used to achive dao for SBAccountImpTest
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.sns.org.model.SBAccount;
/***
 SBAccountImpTest class used to achive dao for SBAccountImpTest
 * 
*/
class SBAccountImpTest {
	List SBAccountListTest;
	/*SBAccountImpTest constructor*/
public SBAccountImpTest() {

	SBAccountListTest = new ArrayList<SBAccount>();
	SBAccount account1 = new SBAccount(1510, "Sundhara", 50000);
	SBAccount account2 = new SBAccount(1511, "Aruthra", 90000);
	SBAccount account3 = new SBAccount(1512, "Viji", 99000);
	SBAccount account4 = new SBAccount(1513, "athvi", 66000);
	
	SBAccountListTest.add(account1);
	SBAccountListTest.add(account2);
	SBAccountListTest.add(account3);
	SBAccountListTest.add(account4);
}
/** 
 * Display all the accounts*
 **/

	@Test
	void testGetAllAccounts() {
		List<SBAccount> actualList = new ArrayList<SBAccount>();
		SBAccountImp daoImp = new SBAccountImp();
		actualList = daoImp.getAllAccounts();
		assertEquals( SBAccountListTest.size(),actualList.size());
	}
	/** 
	 * Display accounts by accountNum*
	 **/
	
	@Test
	void testGetAccountByAccountNumber() {
		SBAccount actual = (SBAccount) SBAccountListTest.get(0);
		SBAccountImp daoImp = new SBAccountImp();
		SBAccount expected = daoImp.getAccountByAccountNumber(1510);
		assertEquals( expected.getAccountHoderName(),actual.getAccountHoderName());
	}
	/*Delete the account*/ 
	@Test
	void testDeleteAccount() {
		List<SBAccount> actualList = new ArrayList<SBAccount>();
		SBAccountImp daoImp = new SBAccountImp();
		daoImp.deleteAccount(1513);
		actualList = daoImp.getAllAccounts();
		assertEquals(SBAccountListTest.size()-1,actualList.size());
	}

}
