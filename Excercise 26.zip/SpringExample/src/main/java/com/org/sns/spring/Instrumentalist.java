/***
 * class: Instrumentalist
 * Description: This class used to to define a instrumentList. Its implement Performer interface
 * Date:12-10-2020
 */
package com.org.sns.spring;

import org.springframework.stereotype.Component;

/***
 * Instrumentalist class used to to define a instrumentList. Its implement Performer interface*/
@Component("Piyano")
public class Instrumentalist implements Performer {
	Saxophone Saxophone;
	/***getters and setters
	 * */
	public Saxophone getSaxophone() {
		return Saxophone;
	}

	public void setSaxophone(Saxophone saxophone) {
		Saxophone = saxophone;
	}
/**
 * *constructor
 * **/
	public Instrumentalist(){
	 System.out.println("Instrumentalist Constructor");
	
}

public void perform() {
	System.out.println("perform calls Instrumentalist ");
	
	Saxophone.play();
}

}
