package com.org.sns.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainMethod$3 {
	/**
	 * Main Method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		 

		Instrumentalist instrumentalist = context.getBean("Piyano", Instrumentalist.class);

		instrumentalist.perform();

	}
}
