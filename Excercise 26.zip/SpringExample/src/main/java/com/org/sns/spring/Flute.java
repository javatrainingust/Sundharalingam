/***
 * Class: Flute
 * Description: This class used to Implement Instrument interface 
 * Date:12-10-2020
 */
package com.org.sns.spring;
/***
 * Flute class used to Implement Flute interface 
 */
public class Flute implements Instrument {
/**
 * Constructor*/
	public Flute() {
		System.out.println("Constructor for flue");
	}

	/***
	 * Play method displays Playing Flute
	 */
	
	public void play() {
		// TODO Auto-generated method stub
		System.out.println(" Flute is Playing ");
	}

}
