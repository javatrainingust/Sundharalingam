/***
 * class: Demo3
 * 
 * Description:this class used to implement Streaming Array sorting
 *
 * Date:09.10.2020
 * 
*/
package com.sns.org.excercize21;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
/***
 * Demo3 class used to implement Streaming Array sorting
 * 
*/
public class Demo3 {
	/**
	 * main method
	 * */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List cats = new ArrayList<Cat>();
		Cat c1=new Cat("Sundhar", 3);
		Cat c2=new Cat("Viji", 1);
		Cat c3=new Cat("Aruthra", 5);
		Cat c4=new Cat("Athvi", 4);
		cats.add(c2);
		cats.add(c1);
		cats.add(c3);
		cats.add(c4);
		
		Stream<Cat> catStream = cats.stream();
		
		Stream<Cat> sortedCatStream = catStream.sorted();
		
		sortedCatStream.forEach((e)->System.out.println(e));
		
		

	}



}
