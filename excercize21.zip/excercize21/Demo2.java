/***
 * class: Demo2
 * 
 * Description:this class used to implement Streaming Array sorting
 *
 * Date:09.10.2020
 * 
*/package com.sns.org.excercize21;

import java.util.stream.Stream;
/***
 *  Demo2 class used to implement Streaming Array sorting
 * 
*/
public class Demo2 {
	/**
	 * main method
	 * */
	public static void main(String[] args) {
		
		Stream<String> sortedStream = Stream.of("suman","viji","athvi", "aruthra").sorted();
		
		sortedStream.forEach((e)->System.out.println(e));

	}
}
