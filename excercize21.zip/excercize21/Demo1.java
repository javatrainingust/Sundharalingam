/***
 * class: Demo1
 * 
 * Description:this class used to implement Streaming Array 
 *
 * Date:09.10.2020
 * 
*/
package com.sns.org.excercize21;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
/***
 * Demo1 class used to implement Streaming Array 
 * 
*/
public class Demo1 {
	/**
	 * main method
	 * */
public static void main(String[] args) {
	Integer[] numbers = {1,2,3,4,5,6,7,8,9};
		
		
	Stream<Integer> numsStream = Arrays.stream(numbers);
		long result = numsStream.map((n)->(n*n)).filter((i)->i>10).count();
		
		System.out.println("The values greater than 10: "+result);
		

	}

}
