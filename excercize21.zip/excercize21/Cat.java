
/**
 * Class : Cat
 * 
 * Description: Class that implements Comparable For sorting the cats based on their age
 * 
 * Date:9/10/2020
 */
package com.sns.org.excercize21;



/**
 * Class that implements Comparable For sorting the cats based on their age
 *
 *
 *
 */
public class Cat implements Comparable<Cat>{
	
	private String name;
	private Integer age;
/**
 * 
 * constructor*/
	public Cat(String name, int age) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	@Override
	public int compareTo(Cat o) {

		return age - o.age;
	}

	@Override
	public String toString() {
		String output = "Cat Name: " + name + "   and its age:" + age;
		return output;

	}
	/**
	 * equal method
	 */
	 public boolean equals(Object obj) {
			
			Cat cat = (Cat)obj;
			
			boolean isEqual = false;
			
			if((this.name.equals(cat.name))&&(this.age.equals(cat.age))) {
				
				isEqual =true;
			}
			
			return isEqual;
		}
	/***
	 * Method hashcode is implemented below
	 * */
     
	@Override
	public int hashCode() {
		
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return  result;
	}

	


}
