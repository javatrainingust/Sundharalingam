/***
 * Class Name:Country
 * Date:22-10-2020
 * Discription: this class used to achive web service 
 */
package com.sns.countrydetails.model;
/***
 *Country class used to achive web service 
 */
public class Country {
/**getters and setters
 * */
private String code;
private String message;

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

public String getCode() {
	return code;
}

public void setCode(String code) {
	this.code = code;
}

public String getDescription() {
	return Description;
}

public void setDescription(String description) {
	Description = description;
}

private String Description;
}
