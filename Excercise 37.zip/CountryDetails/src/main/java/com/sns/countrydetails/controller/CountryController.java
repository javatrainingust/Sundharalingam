/***
 * Class Name:CountryController
 * Date:22-10-2020
 * Discription: this controller class used to achive web service 
 */
package com.sns.countrydetails.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sns.countrydetails.model.Country;

/***
 * CountryController class used to achive web service
 */
@RestController
public class CountryController {

	Map<String, Country> countryDatabase = new HashMap<String, Country>();

	@RequestMapping(value = "/countrys/dummy", method = RequestMethod.GET)
	/**
	 * Create country in that
	 **/
	public String getDummyCountry() {

		Country country = new Country();

		country.setCode("IN");
		country.setDescription("India");
		country.setMessage("Country india Created");
		Country country1 = new Country();
		country1.setCode("US");
		country1.setDescription("United States of America");
		country1.setMessage("Country america Created");

		countryDatabase.put("IN", country);
		countryDatabase.put("US", country1);

		return "success";

	}

	/**
	 * Retravive country by specific
	 **/
	@RequestMapping(value = "/countrys/{code}", method = RequestMethod.GET)
	public Country getCountry(@PathVariable String code) {

		Country country = new Country();

		if (countryDatabase.containsKey(code)) {
			country = countryDatabase.get(code);
			country.setMessage("Country retrieved");

		} else {
			country.setMessage("country not found");

		}

		return country;
	}

	/**
	 * Retravive country
	 **/
	@RequestMapping(value = "/countrys", method = RequestMethod.GET)
	public List<Country> getAllCountry() {

		List<Country> country = new ArrayList<Country>();

		Set<String> countryCodeKeys = countryDatabase.keySet();

		for (String i : countryCodeKeys) {

			country.add(countryDatabase.get(i));
		}

		return country;

	}

	/**
	 * add country
	 */
	@RequestMapping(value = "/countrys", method = RequestMethod.POST)
	public Country createCountry(@RequestBody Country country) {

		System.out.println("country code: " + country.getCode());
		if (countryDatabase.containsKey(country.getCode())) {

			country.setMessage("country already exist");

		} else {

			countryDatabase.put(country.getCode(), country);
			country.setMessage("country created");

		}

		return country;

	}

	/**
	 * Delete the country
	 */
	@RequestMapping(value = "/countrys/{code}", method = RequestMethod.DELETE)
	public Country deleteCountryyee(@PathVariable String code) {

		Country country = new Country();

		if (countryDatabase.containsKey(code)) {
			country = countryDatabase.get(code);

			countryDatabase.remove(code);

			country.setMessage("country deleted");

		} else {

			country.setMessage("country not found");

		}

		return country;

	}

	/***
	 * update the country
	 **/
	@RequestMapping(value = "/countrys/{code}", method = RequestMethod.PUT)
	public Country updateCountry(@PathVariable String code, @RequestBody Country Modifiedcountry) {

		Country country = new Country();

		if (countryDatabase.containsKey(code)) {

			country = countryDatabase.get(code);
			country.setDescription(Modifiedcountry.getDescription());

			country.setMessage("country updated");

		} else {
			country.setMessage("country not found");

		}

		return country;
	}

}
