/***
 * Interface Name:InterestCalculatortest
 * 
 * Description:This class used to handle for InterestCalculatortest's JUnit 
 *
 * Date:30.09.2020
 * 
**/	
package com.sns.org.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.sns.org.model.SBAccount;
/*This class used to handle for InterestCalculatortest's JUnit */
class InterestCalculatorTest {
	
	@Test
	void testIntrestCalculateFloatIntFloat() {
		InterestCalculator ic=new InterestCalculator();
		float actual=ic.intrestCalculate(5000, 5);
		float expected=1250;
		assertEquals(expected, actual);
	}

	@Test
	void testIntrestCalculateDoubleInt() {
		InterestCalculator ic=new InterestCalculator();
		float actual=ic.intrestCalculate(5000, 5, 8);
		float expected=2000;
		assertEquals(expected, actual);
	}

}
