/***
 * interface: SBAccountDAO
 * 
 * Description:this interface used to implement  dao for SBAccount
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import java.util.List;

import com.sns.org.model.FDAccount;
import com.sns.org.model.SBAccount;
/***This interface used to implement  dao for SBAccount*/
public interface SBAccountDAO {
	/*method declaration for SBAccountDAO interface*/
	public List<SBAccount> getAllAccounts();
	
	public SBAccount getAccountByAccountNumber(int accountNum);
	
	public void deleteAccount(int accountNum);
	
	public boolean addAccount(SBAccount fda);
	
	public void updateAccount(SBAccount fda);
}
