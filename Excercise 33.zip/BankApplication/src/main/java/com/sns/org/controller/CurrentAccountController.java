/***
 * Class: CurrentAccountController
 * 
 * Description:this class used to implement  controller for CurrentAccount
 *
 * Date:15.10.2020
 * 
*/
package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sns.org.model.CurrentAccount;
import com.sns.org.servics.CurrentAccountService;
/***
 *CurrentAccountController class used to implement  controller for CurrentAccount
*/
@Controller
public class CurrentAccountController {
	@Autowired
	private CurrentAccountService service;
	
	/**
	 * Get All accounts
	 * */
	@RequestMapping("/caAccount")
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<CurrentAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);
		model.addAttribute("caAccount",accountList );
		return "caAccount";
		
	}
	/**
	 * Get specified account details
	 * */
	@RequestMapping("/viewCurrentAccount")
	public String getAccounts(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		CurrentAccount ca = service.getFDAccountByAccountNumber(Integer.parseInt(accountNumber));
		
		model.addAttribute("key", ca);
		
		
		return "viewCurrentAccount";
		
		
	}
	/**
	 * Delete specified account details
	 * */
	@RequestMapping("/deleteCurrentAccount")
	public String deleteEmployee(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		service.deleteFDAccount(Integer.parseInt(accountNumber));
		
				
		return "redirect:/caAccount";
		
		
	}
}
