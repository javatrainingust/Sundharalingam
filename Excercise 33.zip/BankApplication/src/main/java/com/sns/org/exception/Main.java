/***
 * Classname: Main
 * 
 * Description:This class used for call new InsufficentBalanceException type of exception 
 *
 * Date:09.10.2020
 * 
**/
package com.sns.org.exception;

import com.sns.org.model.SBAccount;

/***
 * Main class used for call new InsufficentBalanceException type of exception
 **/
public class Main {
	/**
	 * main method starting
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SBAccount sb = new SBAccount();

		sb.setAccountHoderName("Sundharalingam");
		sb.setAccountNumber(1510);

		try {
			sb.withdrawMoney(7887);

		} catch (InsufficentBalanceException e) {

			System.out.println("You have " + sb.getBalance() + " Rupees Only: " + e);

		}
	}

}
