
/***
 * Classname:Main
 * 
 * Description:To achive Arraylist and sorting
 *
 * Date:05.10.2020
 * 
***/	
package com.org.collections.cats;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.org.collections.hashsetDemo.Cats;
/***
 * main  class used To achive Cats's Arraylist and sorting**/
public class Main {
public static void main(String[] args) {
	List cat = new ArrayList<Cats>();
	Cats c1=new Cats("Sundhar", 3);
	Cats c2=new Cats("Viji", 1);
	Cats c3=new Cats("Aruthra", 5);
	Cats c4=new Cats("Athvi", 4);
	cat.add(c2);
	cat.add(c1);
	cat.add(c3);
	cat.add(c4);
	
	Iterator<Cats> i1 =cat.iterator();
	
	while(i1.hasNext()){
		
		Cats c = i1.next();
		System.out.println(c);
	}
	
Collections.sort(cat);
System.out.println("After sorting based on albhabetical order of cat name");
Iterator<Cats> i2 =cat.iterator();

while(i2.hasNext()){
	
	Cats c = i2.next();
	System.out.println(c);
}
}
}
