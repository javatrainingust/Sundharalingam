
/***
 * Classname:HashsetDemoCat
 * 
 * Description:To achive Hashset
 *
 * Date:05.10.2020
 * 
***/	
package com.org.collections.hashsetDemo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
/***
 * HashsetDemo class used To achive Hashset
***/
public class HashsetDemoCat {

	public static void main(String[] args) {
		boolean[] b =new boolean[3];
		Set s = new HashSet<Cats>();

		b[0] = s.add(new Cats("Rosy", 2));
		b[1] = s.add(new Cats("pinky", 3));
		b[2] = s.add(new Cats("Rosy", 2));
		
for (int i=0; i<b.length; i++) {
			
			System.out.println("Value inside boolean array:\t"+b[i]);
		}
	
	for(Object o:s) {
		
		System.out.println("Value inside Set:\t"+o);
	}
	
	
	}
}
