package com.org.sns.spring;

public class Guitar implements Instrument{
public Guitar(){
	System.out.println("Guitar constructor");
}

/***
 * Play method displays Playing Guitar
 */

public void play() {
	// TODO Auto-generated method stub
	System.out.println(" Guitar is Playing ");
}

}
