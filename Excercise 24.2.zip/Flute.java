package com.org.sns.spring;

public class Flute implements Instrument {

	public Flute() {
		System.out.println("Constructor for flue");
	}

	/***
	 * Play method displays Playing Flute
	 */
	
	public void play() {
		// TODO Auto-generated method stub
		System.out.println(" Flute is Playing ");
	}

}
