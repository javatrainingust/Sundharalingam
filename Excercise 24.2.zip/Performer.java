/***
 * Performer
 * Description: This interface used to to define performer.
 * Date:12-10-2020
*/package com.org.sns.spring;
/***
 * Performer interface used to to define performer.
*/
public interface Performer {
	/***
	 * 
	 * method declaration*/
public void perform();
;
}
