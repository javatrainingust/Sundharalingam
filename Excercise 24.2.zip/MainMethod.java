package com.org.sns.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainMethod {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContextV2.xml");

		OneManBand oneManBand = context.getBean("OneManBand",OneManBand.class);
		
		oneManBand.perform();
	}
}
