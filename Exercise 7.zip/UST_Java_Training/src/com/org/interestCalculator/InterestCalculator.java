package com.org.interestCalculator;

public class InterestCalculator implements ICalculator {
Float SI, p,r;
int n;
	public float intrestCalculate(float p, int n, float r) {
		SI=(float) ((p*n*r)/100);
		System.out.println("Fixed Deposite");
		System.out.println("Princple:"+p+"\t Tenure:"+n+"\t Ratio:"+r+"%");
		System.out.println("Interest of FD:"+SI);
		System.out.println("****************************");
		return SI;
	}
	
public float intrestCalculate(double p,int n) {
	r=(float) 5.0;
	System.out.println("Saving Account");
	SI=(float) ((p*n*r)/100);
	System.out.println("Princple:"+p+"\t Tenure:"+n+"\t Ratio:"+r+"%");
	System.out.println("Interest of Saving Account:"+SI);
	System.out.println("****************************");
	return SI;
	}
}
