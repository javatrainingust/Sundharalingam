package com.Account.org;

import java.util.Date;
import java.util.Scanner;

import com.org.WithdrawAccount.CurrentAccount;
import com.org.WithdrawAccount.FDAccount;
import com.org.WithdrawAccount.LoanAccount;
import com.org.WithdrawAccount.Renewable;
import com.org.WithdrawAccount.SBAccount;
import com.org.interestCalculator.ICalculator;
import com.org.interestCalculator.InterestCalculator;

public class Account {
	
private int AccountNumber;
private String AcountHoderName;

//private String TypeofAccount;

public int getAccountNumber() {
	System.out.println("Account Number:"+AccountNumber);
	return AccountNumber;
}
public void setAccountNumber(int accountNumber) {
	AccountNumber = accountNumber;
	
}
public String getAcountHoderName() {
	System.out.println("Account Holder Name:"+AcountHoderName);
	return AcountHoderName;
}
public void setAcountHoderName(String acountHoderName) {
	
	AcountHoderName = acountHoderName;
}

public void interestCalculator() {
	System.out.println("Interest calculate mathod calling");
}

public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);

	InterestCalculator interest=new InterestCalculator();
	interest.intrestCalculate(5000.0, 1);
	interest.intrestCalculate(5000,1, 8);
	//calling account class
	/*Account accountObj=new Account();
	accountObj.setAccountNumber(1010);
	accountObj.setAcountHoderName("Sundharalingam");
	
	System.out.println("1.Savings account");
	System.out.println("2.FD Account");
	System.out.println("3.Loan Account");
	System.out.println("4.Current Account");
	System.out.println("Please select  which type of account you want to enter");
	int option=sc.nextInt();
	System.out.println("");
	accountObj.getAcountHoderName();
	accountObj.getAccountNumber();
	switch (option) {
	case 1:
		
		System.out.println("Type of account:1.Savings account");
		SBAccount sba=new SBAccount();
		sba.setBalance(5000);
		sba.withdrawMoney(500);
		sba.setYear(1);
		sba.setRatio(5);
		sba.getYear();
		sba.getRatio();
		
		sba.interestCalculator();
		
		break;
	case 2:

		System.out.println("Type of account:2.FD Account");
		FDAccount fda=new FDAccount();
		fda.setFDAmount(50000);
	
		fda.setAutoRenewal("Yes");
		fda.getFDAmount();
		
		fda.setRatio(7);
		fda.getRatio();
		fda.setTenture(1);
		fda.setAutoRenewal("Yes");
		Account fdaa=new FDAccount();
		fdaa.autoRenewal(1);
		fda.interestCalculator();
		break;
	case 3:

		System.out.println("Type of account:3.Loan Account");
		LoanAccount la=new LoanAccount();
		la.setEMI(5000);
		la.setLoanOutStanding(2000);
		la.setTenture(3);
		la.getEMI();
		la.getTenture();
		la.getLoanOutStanding();
		break;
	case 4:

		System.out.println("Type of account:4.Current Account");
		CurrentAccount ca=new CurrentAccount();
		ca.setOverdraftLimit(5000);
		ca.getOverdraftLimit();
		break;

	default:
		System.out.println("You Given Wrong Option");
		break;
	}
	SBAccount acc=new SBAccount();*/
	
	
}
public void autoRenewal(int tenuree) {
	// TODO Auto-generated method stub
	
}
}
