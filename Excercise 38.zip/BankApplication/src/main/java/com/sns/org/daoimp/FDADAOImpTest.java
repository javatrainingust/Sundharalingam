/***
 * Classname: FDADAOImpTest
 * 
 * Description:this class used to achive dao for FDADAOImpTest
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;


import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;
import com.sns.org.servics.FDAccountService;

/*** FDADAOImpTest class used to achive dao for FDADAOImp */
class FDADAOImpTest {
	List fdAccountListTest;
	FDAccountService service= new FDAccountService();
	/*** constructor FDADAOImpTest class */
	public FDADAOImpTest() {
		fdAccountListTest = new ArrayList<FDAccount>();
			FDAccount account1 = new FDAccount(1510, "Sundhara", 50000, 2, 8);
		FDAccount account2 = new FDAccount(1511, "Viji", 80000, 2, 8);
		FDAccount account3 = new FDAccount(1512, "Aruthra", 90000, 2, 8);
		FDAccount account4 = new FDAccount(1513, "Athvi", 20000, 2, 8);

		fdAccountListTest.add(account1);
		fdAccountListTest.add(account2);
		fdAccountListTest.add(account3);
		fdAccountListTest.add(account4);
	}
	/**
	 * Display all the accounts sorted by Balance *
	 **/
	
	@Test
void testGetAllCurrentAccountSortedByBalance() {
		
      String expectedValue = "Sundhara";
		
List<FDAccount> fdAccount = service.getAllFDAccountsSortedByBasicBalance();
		
	String actualValue = fdAccount.get(0).getAccountHoderName();
		
	assertEquals(expectedValue, actualValue);
		
	}
	/**
	 * Display all the accounts sorted by names *
	 **/ @Test
	void testGetAllCurrentAccountSortedByNames() {
			
			String expectedValue = "Sundhara";
			
			List<FDAccount> fdAccount = service.getAllAccountsSortedByNames();
			
			String actualValue = fdAccount.get(0).getAccountHoderName();
			
		assertEquals(expectedValue, actualValue);
		}

	/**
	 * Display all the accounts*
	 **/
/*
	@Test
	void testGetAllAccounts() {
		List<FDAccount> expected = new ArrayList<FDAccount>();
		FDADAOImp daoImp = new FDADAOImp();
		expected = daoImp.getAllAccounts();
		assertEquals( expected.size(),fdAccountListTest.size());
	
	}

	/**
	 * Display accounts by accountNum*
	 **/
/*	@Test
	void testGetAccountByAccountNumber() {
		FDAccount expected = (FDAccount) fdAccountListTest.get(0);
		FDADAOImp daoImp = new FDADAOImp();
		FDAccount actual = daoImp.getAccountByAccountNumber(1510);
		assertEquals(expected.getAccountHoderName(), actual.getAccountHoderName());
	}

	/***
	 * Delete the account*
	 **/
/*	@Test
	void testDeleteAccount() {
		List<FDAccount> expected = new ArrayList<FDAccount>();
		FDADAOImp daoImp = new FDADAOImp();
		daoImp.deleteAccount(1513);
		expected = daoImp.getAllAccounts();
		assertEquals(expected.size(),fdAccountListTest.size() - 1);
	}
*/
	/***
	 * add account
	 * */
	/*	@Test
		void testAddAccount() {
			FDADAOImp daoImp=new FDADAOImp();
			int expected=4;
			service.addfdAccount(new FDAccount(1510, "Sundhara", 50000, 2, 8));
			service.addfdAccount(new FDAccount(1511, "Viji", 80000, 2, 8));
			service.addfdAccount(new FDAccount(1512, "Aruthra", 90000, 2, 8));
			service.addfdAccount(new FDAccount(1513, "Athvi", 20000, 2, 8));
			List<FDADAO> actual=service.getAllAccounts();
			assertEquals(expected, actual.size());
			
			
		}
		*/
	/*	  update account*
		@Test
		void testUpdateAccount() {
			float expected=800000;
			FDADAOImp daoImp = new FDADAOImp();
			FDAccount actual = daoImp.getAccountByAccountNumber(50000);
			
			assertEquals(expected, actual.getFixedDepositAmount());
		}
	*/
}
