/***
 * Class: LoanAccountController
 * 
 * Description:this class used to implement  controller for LoanAccount
 *
 * Date:15.10.2020
 * 
*/package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sns.org.servics.LoanAccountService;
import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;
import com.sns.org.model.LoanAccount;
/***
 *  LoanAccountController class used to implement  controller for LoanAccount
*/
@Controller
public class LoanAccountController {
	@Autowired
	private LoanAccountService service;
	@RequestMapping("/showLoanform")

	public String showAccountForm(Model model) {

		LoanAccount ca = new LoanAccount();

		model.addAttribute("key", ca);
		return "addLaAccount";

	}
/**current account adding*/
	@RequestMapping("/addLoanAccount")
	public String addAccount(@ModelAttribute("LoanAccount") LoanAccount ca) {

		service.addloanAccount(ca);

		return "redirect:/loanAccount";

	}
	/**
	 * Get All Accounts
	 * */
	@RequestMapping("/loanAccount")
	
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<LoanAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);
		model.addAttribute("loanAccount",accountList );
		
		
		return "loanAccount";
		
	}	/**
	 * Get All Accounts sortLoanAccountByName
	 * */
	@RequestMapping("/sortLoanAccountByName")
	
	public String getAllLoanAccountByName(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<LoanAccount> accountList = service.getAllAccountsSortedByNames();
		System.out.println(accountList);
		model.addAttribute("loanAccount",accountList );
		
		
		return "loanAccount";
		
	}	/**
	 * Get All Accounts sortLoanAccountByName
	 * */
	@RequestMapping("/sortLoanAccountBybalance")
	
	public String getAllLoanAccountBybalance(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<LoanAccount> accountList = service.getAllFDAccountsSortedByEMI();
		System.out.println(accountList);
		model.addAttribute("loanAccount",accountList );
		
		
		return "loanAccount";
		
	}
	/**
	 * update Account*/
	@RequestMapping("/updateLoanAccounts")
	public String updateAccounts(@ModelAttribute("LoanAccount") LoanAccount ca) {
		
		
		service.updateloanAccount(ca);
		
		return "redirect:/loanAccount";
		
		
	}
	/**
	 * Get specified account details
	 * */
	@RequestMapping("/viewLoanAccount")
	public String getAccounts(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		LoanAccount la = service.getLoanAccountByAccountNumber(Integer.parseInt(accountNumber));
		
		model.addAttribute("key", la);
		
		
		return "viewLoanAccount";
		
		
	}
	/**
	 * Delete specified account details
	 * */
	@RequestMapping("/deleteLoanAccount")
	public String deleteEmployee(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		service.deleteLoanAccount(Integer.parseInt(accountNumber));
		
				
		return "redirect:/loanAccount";
		
		
	}
}
