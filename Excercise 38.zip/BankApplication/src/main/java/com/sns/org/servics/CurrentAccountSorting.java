/***
 * class: CurrentAccountSorting
 * 
 * Description:this class used to sort CurrentAccount accounts
 *
 * Date:07.10.2020
 * 
*/
package com.sns.org.servics;
/***
 CurrentAccountSorting class used to sort CurrentAccount accounts
*/
public class CurrentAccountSorting {
	/**
	 * 
	 * Main method
	 */
	public static void main(String[] args) {
		CurrentAccountService service =  new CurrentAccountService();
		System.out.println("printing all accounts");
		
		service.getAllAccounts();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print Accounts after sorting");
		service.getAllAccountsSortedByNames();
		System.out.println("----------------------");
		System.out.println("Print accounts  after sorting based on balance");
		service.getAllPermanentEmployeesSortedByBasicSalary();
	}

}
