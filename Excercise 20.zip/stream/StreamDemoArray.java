/***
 * class: StreamDemoArray
 * 
 * Description:this class used to implement Streaming Array 
 *
 * Date:09.10.2020
 * 
*/
package com.sns.fuctional.stream;

import java.util.stream.Stream;

/***
 * StreamDemoArray class used to implement Streaming Array
 */
public class StreamDemoArray {
	/**
	 * 
	 * main method starting
	 */
	public static void main(String[] args) {
		Stream<String> myStream = Stream.of("suman", "sundhar", "viji");

		long noOfElements = myStream.filter((i) -> i == i).count();

		System.out.println("Number of student : " + noOfElements);

	}

}
