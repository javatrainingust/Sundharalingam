/***
 * class: StreamDemoArrayList
 * 
 * Description:this class used to implement Streaming ArrayList 
 *
 * Date:09.10.2020
 * 
*/
package com.sns.fuctional.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/***
 * StreamDemoArrayList class used to implement Streaming ArrayList
 */
public class StreamDemoArrayList {
	/**
	 * main method
	 */
	public static void main(String[] args) {
		List<String> studentNames = new ArrayList<String>();

		studentNames.add("Suman");
		studentNames.add("Sundhar");
		studentNames.add("Viji");
		studentNames.add("Aruthra");
		studentNames.add("Athvi");

		Stream<String> tempStream = studentNames.stream();

		long stdcount = tempStream.count();

		System.out.println("Student count: " + stdcount);
	}

}
