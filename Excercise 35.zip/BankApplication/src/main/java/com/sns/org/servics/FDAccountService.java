/***
 * class: FDAccountService
 * 
 * Description:this class used to implement FDAccountService
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.servics;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sns.org.daoimp.FDADAO;
import com.sns.org.daoimp.FDADAOImp;
import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;

/***
 * FDAccountService class used to implement FDAccountService
 * 
 */
@Service
public class FDAccountService {
	/* constructor */
@Autowired
	FDADAO daoImpl;
	/**
	 * constructor
	 **/
	public FDAccountService() {
		// TODO Auto-generated constructor stub

		daoImpl = new FDADAOImp();

	}

	/**
	 * Display all the accounts*
	 **/

	public List<FDAccount> getAllAccounts() {
		List FDAccountList = daoImpl.getAllAccounts();

		// FDAccount FDAccount = null;
		Iterator<FDAccount> iterator = FDAccountList.iterator();

		while (iterator.hasNext()) {

			FDAccount fd = iterator.next();

			System.out.println("FD Account Id: " + fd.getAccountNumber());
			System.out.println("FD Account Holder Name: " + fd.getAccountHoderName());
			System.out.println("FD Account Amount: " + fd.getFixedDepositAmount());
			System.out.println("FD Ratio:" + fd.getRatio() + "%");
			System.out.println("FD Tenture:" + fd.getTenture() + "Years");
			System.out.println("************************************************");

		}

		return FDAccountList;
	}

	/**
	 * Display accounts by accountNum*
	 **/

	public FDAccount getFDAccountByAccountNumber(int getAccountNumber) {
		FDAccount fd = daoImpl.getAccountByAccountNumber(getAccountNumber);

		System.out.println("FD Account Id: " + fd.getAccountNumber());
		System.out.println("FD Account Holder Name: " + fd.getAccountHoderName());
		System.out.println("FD Account Amount: " + fd.getFixedDepositAmount());
		System.out.println("FD Ratio:" + fd.getRatio() + "%");
		System.out.println("FD Tenture:" + fd.getTenture() + "Years");
		return fd;

	}

	/**
	 * Delete the account
	 */
	public void deleteFDAccount(int accountNumber) {

		daoImpl.deleteAccount(accountNumber);
		;

	}

	/***
	 * sort all accounts by account holder names
	 ***/
	public List<FDAccount> getAllAccountsSortedByNames() {

		List<FDAccount> fdAccountList = daoImpl.getAllAccounts();

		//Collections.sort(fdAccountList);
Stream<FDAccount> fdAccountStream = fdAccountList.stream();
		
		Stream<FDAccount> sortedStream = fdAccountStream.sorted();
		
		List sortedFDAccountList = sortedStream.collect(Collectors.toList());
		
		
		
		Iterator<FDAccount> iterator = sortedFDAccountList.iterator();

		while (iterator.hasNext()) {

			FDAccount fd = iterator.next();

			System.out.println("FD Account Id: " + fd.getAccountNumber());
			System.out.println("FD Account Holder Name: " + fd.getAccountHoderName());
			System.out.println("FD Account Amount: " + fd.getFixedDepositAmount());
			System.out.println("FD Ratio:" + fd.getRatio() + "%");
			System.out.println("FD Tenture:" + fd.getTenture() + "Years");
			System.out.println("*********************************************");
		}

		return fdAccountList;
	}

	/***
	 * sort all accounts by FD Amount
	 ***/
	public List<FDAccount> getAllFDAccountsSortedByBasicBalance() {

		List<FDAccount> fdAccountList = daoImpl.getAllAccounts();

		//Collections.sort(fdAccountList, new FDAccountComparator());
Stream<FDAccount> fDAccounttStream = fdAccountList.stream();
		
		Stream<FDAccount> sortedStream = fDAccounttStream.sorted(new FDAccountComparator());
		
		List sortedFDAccountList = sortedStream.collect(Collectors.toList());
		
		Iterator<FDAccount> iterator = sortedFDAccountList.iterator();

		while (iterator.hasNext()) {

			FDAccount fd = iterator.next();

			System.out.println("FD Account Id: " + fd.getAccountNumber());
			System.out.println("FD Account Holder Name: " + fd.getAccountHoderName());
			System.out.println("FD Account Amount: " + fd.getFixedDepositAmount());
			System.out.println("FD Ratio:" + fd.getRatio() + "%");
			System.out.println("FD Tenture:" + fd.getTenture() + "Years");
			System.out.println("*********************************************");
		}

		return fdAccountList;
	}
	
	/**
	 * add account
	 * */	public void addfdAccount(FDAccount fdAccount) {
		
		boolean isAdded = daoImpl.addAccount(fdAccount);
			
		
		if(!isAdded){
			
			System.out.println("The account already exist");
		}
		else{
			System.out.println("The account successfully added");
			
		}
		
	}
	/**
	 * update account
	 * */
	public void updatefdAccount(FDAccount fdAccount){
		
		daoImpl.updateAccount(fdAccount);
		
	}


}
