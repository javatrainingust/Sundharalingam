package com.sns.org.servics;

public class LoanAccountSorting {
	/**
	 * 
	 * Main method
	 */
	public static void main(String[] args) {
		LoanAccountService service =  new LoanAccountService();
		System.out.println("printing all accounts");
		
		service.getAllAccounts();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print Accounts after sorting");
		service.getAllAccountsSortedByNames();
		System.out.println("----------------------");
		System.out.println("Print accounts  after sorting based on balance");
		service.getAllFDAccountsSortedByEMI();
	}
}
