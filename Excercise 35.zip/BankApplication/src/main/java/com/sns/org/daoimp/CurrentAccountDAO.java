/***
 * interface: CurrentAccountDAO
 * 
 * Description:this interface used to implement  dao for CurrentAccount
 *
 * Date:06.10.2020
 * 
*/
package com.sns.org.daoimp;

import java.util.List;

import com.sns.org.model.CurrentAccount;
import com.sns.org.model.FDAccount;

/***
 * This interface used to implement dao for CurrentAccount
 * 
 */
public interface CurrentAccountDAO {
	/**
	 * method declaration for CurrentAccountDAO interface
	 */
	public List<CurrentAccount> getAllAccounts();

	public CurrentAccount getAccountByAccountNumber(int accountNum);

	public void deleteAccount(int accountNum);

	public boolean addAccount(CurrentAccount fda);

	public void updateAccount(CurrentAccount fda);
}
