/***
 * Class: SBAccountController
 * 
 * Description:this class used to implement  controller for SBAccount
 *
 * Date:15.10.2020
 * 
*/
package com.sns.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sns.org.model.LoanAccount;
import com.sns.org.model.SBAccount;

import com.sns.org.servics.SBAccountService;
/***
 *SBAccountController class used to implement  controller for SBAccount
*/
@Controller
public class SBAccountController {
	@Autowired
	private SBAccountService service;
	@RequestMapping("/showSBform")

	public String showAccountForm(Model model) {

		SBAccount ca = new SBAccount();

		model.addAttribute("key", ca);
		return "addSBAccount";

	}
/**current account adding*/
	@RequestMapping("/addSBAccount")
	public String addAccount(@ModelAttribute("SBAccount") SBAccount ca) {

		service.addSBAccount(ca);

		return "redirect:/sbAccount";

	}
	/**
	 * update Account*/
	@RequestMapping("/updateSBAccounts")
	public String updateAccounts(@ModelAttribute("SBAccount") SBAccount ca) {
		
		
		service.updateSBAccount(ca);
		
		return "redirect:/sbAccount";
		
		
	}
	/**
	 * Get All Accounts
	 * */
	
	@RequestMapping("/sbAccount")
	
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<SBAccount> accountList = service.getAllAccounts();
		System.out.println(accountList);
		model.addAttribute("sbAccount",accountList );
		
		
		return "sbAccount";
		
	}
	/**
	 * Get specified account details
	 * */
	@RequestMapping("/viewSBAccount")
	public String getAccounts(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		SBAccount sb = service.getSBAccountByAccountNumber(Integer.parseInt(accountNumber));
		
		model.addAttribute("key", sb);
		
		
		return "viewSBAccount";
		
		
	}
	/**
	 * Delete specified account details
	 * */
	@RequestMapping("/deleteSBAccount")
	public String deleteEmployee(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		service.deleteSBAccount(Integer.parseInt(accountNumber));
		
				
		return "redirect:/sbAccount";
		
		
	}
}
