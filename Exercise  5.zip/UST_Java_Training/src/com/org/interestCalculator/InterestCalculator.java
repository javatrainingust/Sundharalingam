package com.org.interestCalculator;

public class InterestCalculator {
Float SI;
	public float intrestCalculate(float p, int n, float r) {
		SI=(p*n*r)/100;
		//System.out.println(SI);
		return SI;
	}
}
